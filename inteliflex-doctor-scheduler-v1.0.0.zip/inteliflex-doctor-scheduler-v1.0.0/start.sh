#!/usr/bin/env bash
# Local start helper. For production, use the per-clinic Docker Compose setup.
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js 22.9+ is required. Install it, then run npm ci." >&2
  exit 1
fi

node -e 'const [major, minor] = process.versions.node.split(".").map(Number); if (major < 22 || (major === 22 && minor < 9)) { console.error(`Node.js 22.9+ required; found ${process.versions.node}`); process.exit(1); }'

if [[ ! -d node_modules ]]; then
  echo "Dependencies are not installed. Run 'npm ci' first." >&2
  exit 1
fi

npm start
