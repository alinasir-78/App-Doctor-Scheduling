# INTELIFLEX SOLUTIONS — WhatsApp Doctor Scheduling

A single-clinic appointment scheduler with a staff dashboard and a text-based WhatsApp conversation flow for booking, clinic/service inquiries, and appointment reminders. Each clinic gets a separate application instance, database/data volume, environment file, hostname, and Meta credential set. This is not a shared multi-clinic or voice-call product.

## Implementation and verification status

The missing server, SQLite data layer, WhatsApp text flow, scheduling logic, and dashboard have been reconstructed from this repository’s tests and deployment notes. The local preflight and all 12 repository test suites pass. Tests run against temporary, isolated SQLite databases and blank Meta credentials.

That verifies local behavior only. A Docker/Render build, real Meta webhook delivery, clinic-specific configuration, and a production security/privacy review have **not** been completed here. Do not treat the test result as production approval, HIPAA/BAA compliance, or evidence that a clinic is ready to handle identifiable patient information.

## Runtime features

- WhatsApp text scheduling with clinic-time-zone-aware availability, expiring slot holds, conflict checks, confirmation messages, and booking notifications.
- Inquiry responses for doctors, services/prices, clinic location, and a patient’s upcoming appointments.
- Staff sign-in, first-login password changes, role checks, per-doctor calendar filtering, and a small per-instance login-failure throttle.
- Doctor and schedule setup, clinic settings, appointment listing/status updates through the API, and patient-contact CSV/XLSX import.
- Appointment CSV/XLSX exports and an authenticated patient import template.
- Meta WhatsApp Cloud API webhook at `/api/whatsapp/webhook`, with production signature verification.

## Run locally

Node.js 22.9+ is required. SQLite is stored at `data/doctor_agent.db` by default in development; this path is ignored by Git. To use another file, set `DATABASE_PATH`.

```bash
npm ci
npm run build
npm test
npm start
```

`npm run build` is a source preflight, not a bundling step. `npm test` runs all 12 suites sequentially, each with a fresh temporary database and Meta credentials explicitly blanked. `npm start` serves the dashboard and API on port 3000 by default.

Non-production startup creates test/sample fixtures for local development. They are not seeded in production. Do not reuse test passwords or fixtures for any live clinic.

## Per-clinic deployment

INTELIFLEX hosts the application centrally; a clinic does not need to run a cloud server on its website. Deploy a distinct instance and persistent volume for each clinic. A dedicated VM per clinic gives the strongest machine-level separation. Separate Compose projects and volumes on one VM are a lower-cost alternative, but the host is shared.

Start from `.env.example`, create a **unique** `BOOTSTRAP_ADMIN_USERNAME`, `BOOTSTRAP_ADMIN_EMAIL`, and password of at least 16 characters for the fresh production database, then remove the bootstrap password from the running environment after first startup. Keep each clinic’s Meta credentials in its own protected secret store. The app binds to port 3000 inside the container; Compose publishes it on VM loopback for Nginx.

See [`DEPLOYMENT_GUIDE.md`](DEPLOYMENT_GUIDE.md) for the per-clinic VPS/Compose, HTTPS, backup, and Meta setup steps. `render.yaml` is an optional paid single-clinic template; instantiate a separate Render service and disk per clinic.

## Data and privacy

The tracked `doctor_agent.db` file is excluded from the Docker build context and must **never** be used as a clinic database. It remains in Git history; `.gitignore` does not remove historical copies. Create a fresh per-clinic database and treat any existing repository database as sensitive until it has been reviewed.

Patient/contact and appointment data are sensitive. Use a protected persistent volume, restrict host and backup access, encrypt backups, define retention/deletion procedures, and test restores. The application’s use of SQLite assumes one app process/replica for a database file. No HIPAA or BAA claim is made; obtain legal, privacy, and security review of the complete data flow and vendors before using real patient information.
