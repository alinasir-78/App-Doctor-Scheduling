'use strict';

// Production entry point: never install packages at runtime or guess which
// server file to load. Fail clearly if the application source is incomplete.
const fs = require('node:fs');
const path = require('node:path');

require('dotenv').config({ path: path.join(__dirname, '.env') });

const serverFile = path.join(__dirname, 'src', 'server.js');
if (!fs.existsSync(serverFile)) {
  console.error(`Startup blocked: required application entry point is missing: ${serverFile}`);
  console.error('Restore the application source before starting or deploying this package.');
  process.exit(1);
}

try {
  require(serverFile);
} catch (error) {
  console.error('Failed to load the application server:', error);
  process.exit(1);
}
