'use strict';

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));
const state = { user: null, doctors: [], services: [], appointments: [], clients: [], users: [], settings: null };

async function api(path, options = {}) {
  const headers = new Headers(options.headers || {});
  const isForm = options.body instanceof FormData;
  if (options.body && !isForm && !headers.has('Content-Type')) headers.set('Content-Type','application/json');
  headers.set('X-Requested-With','fetch');
  const response = await fetch(path,{ ...options, headers, credentials:'same-origin' });
  const type = response.headers.get('content-type') || '';
  const payload = type.includes('application/json') ? await response.json() : await response.text();
  if (!response.ok) throw new Error(payload?.error || `Request failed (${response.status})`);
  return payload;
}

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}

function showToast(message, isError = false) {
  const element = $('#toast');
  element.textContent = message;
  element.classList.toggle('error-toast',isError);
  element.classList.add('visible');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => element.classList.remove('visible'),3500);
}

function showLogin(message = '') {
  $('#app-view').classList.add('hidden');
  $('#login-view').classList.remove('hidden');
  $('#login-error').textContent = message;
}

function showApp(user) {
  state.user = user;
  $('#login-view').classList.add('hidden');
  $('#app-view').classList.remove('hidden');
  $('#user-label').textContent = `${user.fullName || user.username} · ${user.role}`;
  const canManageClinic = ['admin','director'].includes(user.role);
  const canViewPatients = ['admin','director','receptionist'].includes(user.role);
  $$('[data-admin-only]').forEach((element) => element.classList.toggle('hidden',!canManageClinic));
  $$('[data-staff-only]').forEach((element) => element.classList.toggle('hidden',!canViewPatients));
  $('#appointment-exports').classList.toggle('hidden',user.role === 'doctor');
  const administratorOption = $('#user-role').querySelector('[data-admin-role]');
  administratorOption.hidden = user.role !== 'admin';
  const now = new Date();
  $('#current-date').textContent = new Intl.DateTimeFormat(undefined,{weekday:'long',year:'numeric',month:'long',day:'numeric'}).format(now);
  if (user.must_change_password) $('#password-dialog').showModal();
  else refreshAll().catch((error) => showToast(error.message,true));
}

function activatePage(name) {
  $$('.page').forEach((page) => page.classList.toggle('active',page.id === `page-${name}`));
  $$('.nav-link').forEach((button) => button.classList.toggle('active',button.dataset.page === name));
  const title = { dashboard:'Overview',appointments:'Appointments',doctors:'Doctors',patients:'Patients',settings:'Clinic setup',users:'User accounts' }[name] || 'Overview';
  $('#page-title').textContent = title;
  if (name === 'appointments') loadAppointments().catch((error) => showToast(error.message,true));
  if (name === 'patients') loadClients().catch((error) => showToast(error.message,true));
  if (name === 'users') loadUsers().catch((error) => showToast(error.message,true));
}

async function loadDoctors() {
  const response = await api('/api/doctors');
  state.doctors = response.doctors || [];
  $('#metric-doctors').textContent = state.doctors.filter((doctor) => doctor.is_active).length;
  $('#doctors-list').innerHTML = state.doctors.length ? state.doctors.map((doctor) => `
    <article class="doctor-card"><div class="avatar">${esc((doctor.name || 'D').slice(0,1))}</div><div><h3>${esc(doctor.name)}</h3><p>${esc(doctor.title || doctor.specialty)}</p><span class="tag">${esc(doctor.specialty)}</span></div></article>
  `).join('') : '<p class="empty-state">No doctors have been configured yet.</p>';
  const select = $('#service-doctor');
  if (select) {
    const selected = select.value;
    select.innerHTML = '<option value="">All doctors</option>' + state.doctors.map((doctor) => `<option value="${esc(doctor.id)}">${esc(doctor.name)}</option>`).join('');
    select.value = selected;
  }
  const appointmentDoctor = $('#appointment-doctor');
  if (appointmentDoctor) {
    const selected = appointmentDoctor.value;
    appointmentDoctor.innerHTML = state.doctors.map((doctor) => `<option value="${esc(doctor.id)}">${esc(doctor.name)}</option>`).join('');
    appointmentDoctor.value = selected || String(state.doctors[0]?.id || '');
    updateAppointmentServices();
  }
  const userDoctor = $('#user-doctor');
  if (userDoctor) {
    const selected = userDoctor.value;
    userDoctor.innerHTML = state.doctors.filter((doctor) => doctor.is_active).map((doctor) => `<option value="${esc(doctor.id)}">${esc(doctor.name)}</option>`).join('');
    userDoctor.value = selected || String(state.doctors.find((doctor) => doctor.is_active)?.id || '');
  }
}

function updateAppointmentServices() {
  const select = $('#appointment-service');
  if (!select) return;
  const doctorId = Number($('#appointment-doctor').value);
  const available = state.services.filter((service) => !service.doctor_id || Number(service.doctor_id) === doctorId);
  const selected = select.value;
  select.innerHTML = available.map((service) => `<option value="${esc(service.id)}">${esc(service.name)} · ${esc(service.duration_minutes)} min</option>`).join('');
  select.value = available.some((service) => String(service.id) === selected) ? selected : String(available[0]?.id || '');
}

async function loadServices() {
  const response = await api('/api/services');
  state.services = response.services || [];
  $('#services-list').innerHTML = state.services.length ? state.services.map((service) => {
    const doctor = state.doctors.find((item) => Number(item.id) === Number(service.doctor_id));
    return `<article class="service-row"><div><strong>${esc(service.name)}</strong><small>${esc(service.duration_minutes)} minutes${doctor ? ` · ${esc(doctor.name)}` : ' · Available with any doctor'}</small></div><strong>${esc(service.price)}</strong></article>`;
  }).join('') : '<p class="empty-state">No services configured. Add at least one service to enable appointment scheduling.</p>';
  updateAppointmentServices();
}

function appointmentTable(rows, allowActions = true) {
  if (!rows.length) return '<p class="empty-state">No appointments to show.</p>';
  const canManage = allowActions && ['admin','director','receptionist'].includes(state.user?.role);
  const statuses = ['confirmed','tentative','completed','cancelled','no_show'];
  return `<table><thead><tr><th>Patient</th><th>Doctor</th><th>Date & time</th><th>Service</th><th>Status</th></tr></thead><tbody>${rows.map((item) => `
    <tr><td><strong>${esc(item.patient_name)}</strong><small>${esc(item.client_phone)}</small></td><td>${esc(item.doctor_name)}</td><td>${esc(item.date)}<small>${esc(item.start_time)}–${esc(item.end_time)}</small></td><td>${esc(item.service_name)}</td><td><span class="status-pill ${esc(item.status)}">${esc(item.status)}</span>${canManage ? `<div class="status-actions"><select aria-label="New status for ${esc(item.id)}" data-status-for="${esc(item.id)}">${statuses.map((status) => `<option value="${status}" ${status === item.status ? 'selected' : ''}>${status.replace('_',' ')}</option>`).join('')}</select><button class="text-button" type="button" data-save-status="${esc(item.id)}">Save</button></div>` : ''}</td></tr>
  `).join('')}</tbody></table>`;
}

async function loadAppointments() {
  const query = new URLSearchParams();
  if ($('#appointment-search').value.trim()) query.set('search',$('#appointment-search').value.trim());
  const response = await api(`/api/appointments${query.size ? `?${query}` : ''}`);
  state.appointments = (response.appointments || []).sort((a,b) => a.date.localeCompare(b.date) || a.start_time.localeCompare(b.start_time));
  $('#appointments-list').innerHTML = appointmentTable(state.appointments);
  $('#dashboard-appointments').innerHTML = appointmentTable(state.appointments.slice(0,6),false);
  $('#metric-appointments').textContent = state.appointments.filter((item) => ['confirmed','tentative'].includes(item.status)).length;
}

async function loadClients() {
  const response = await api('/api/clients');
  state.clients = response.clients || [];
  const patientCount = state.clients.reduce((total,client) => total + (client.patients || []).length,0);
  $('#metric-patients').textContent = patientCount;
  if (!state.clients.length) {
    $('#patients-list').innerHTML = '<p class="empty-state">No patient contacts have been added.</p>';
    return;
  }
  $('#patients-list').innerHTML = `<table><thead><tr><th>WhatsApp contact</th><th>Account holder</th><th>Patient profiles</th></tr></thead><tbody>${state.clients.map((client) => `
    <tr><td>${esc(client.phone)}</td><td>${esc(client.registered_name)}</td><td>${(client.patients || []).map((patient) => `<span class="tag">${esc(patient.full_name)} · ${esc(patient.relationship)}</span>`).join(' ')}</td></tr>
  `).join('')}</tbody></table>`;
}

async function loadSettings() {
  if (!['admin','director'].includes(state.user?.role)) return;
  const response = await api('/api/settings');
  state.settings = response.settings || {};
  const form = $('#settings-form');
  for (const [key,value] of Object.entries(state.settings)) {
    const field = form.elements.namedItem(key);
    if (field && value !== null && value !== undefined) field.value = value;
  }
  $('#clinic-name').textContent = state.settings.business_name || 'Your clinic';
  const timezone = state.settings.timezone || 'local time';
  $('#clinic-clock').textContent = `Configured time zone: ${timezone}. Use this instance’s own clinic settings.`;
}

async function loadUsers() {
  if (!['admin','director'].includes(state.user?.role)) return;
  const response = await api('/api/users');
  state.users = response.users || [];
  $('#users-list').innerHTML = state.users.length ? `<table><thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Role</th><th>Account</th><th></th></tr></thead><tbody>${state.users.map((user) => `
    <tr><td>${esc(user.full_name)}</td><td>${esc(user.username)}</td><td>${esc(user.email)}</td><td>${esc(user.role)}</td><td>${Number(user.is_active) ? 'Active' : 'Deactivated'}</td><td><button class="text-button" type="button" data-reset-user="${esc(user.id)}">Reset password</button></td></tr>
  `).join('')}</tbody></table>` : '<p class="empty-state">No user accounts configured.</p>';
}

async function refreshAll() {
  await loadDoctors();
  const tasks = [loadAppointments(),loadServices()];
  if (['admin','director','receptionist'].includes(state.user?.role)) tasks.push(loadClients());
  if (['admin','director'].includes(state.user?.role)) tasks.push(loadSettings(),loadUsers());
  const results = await Promise.allSettled(tasks);
  for (const result of results) if (result.status === 'rejected') showToast(result.reason.message,true);
}

$('#login-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('#login-error').textContent = '';
  const data = new FormData(event.currentTarget);
  try {
    const result = await api('/api/auth/login',{method:'POST',body:JSON.stringify({username:data.get('username'),password:data.get('password')})});
    showApp(result.user);
  } catch (error) { showLogin(error.message); }
});

$('#forgot-password').addEventListener('click', async () => {
  const identifier = $('#login-username').value.trim();
  if (!identifier) return showLogin('Enter your username, email, or registered phone first.');
  try {
    const result = await api('/api/auth/forgot-password',{method:'POST',body:JSON.stringify({identifier})});
    showLogin(result.message || 'If the account can be verified, reset instructions will be sent to its registered contact.');
  } catch (error) { showLogin(error.message); }
});

$('#logout-button').addEventListener('click', async () => {
  try { await api('/api/auth/logout',{method:'POST',body:JSON.stringify({})}); } catch {}
  state.user = null;
  showLogin();
});

$('#password-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  $('#password-error').textContent = '';
  try {
    await api('/api/auth/change-password',{method:'POST',body:JSON.stringify({newPassword:data.get('newPassword'),confirmPassword:data.get('confirmPassword')})});
    $('#password-dialog').close();
    state.user.must_change_password = 0;
    showToast('Password updated.');
    refreshAll().catch((error) => showToast(error.message,true));
  } catch (error) { $('#password-error').textContent = error.message; }
});

$$('.nav-link').forEach((button) => button.addEventListener('click',() => activatePage(button.dataset.page)));
$$('[data-go]').forEach((button) => button.addEventListener('click',() => activatePage(button.dataset.go)));

$('#refresh-appointments').addEventListener('click',() => loadAppointments().catch((error) => showToast(error.message,true)));
$('#appointment-search').addEventListener('input',() => {
  window.clearTimeout(loadAppointments.timer);
  loadAppointments.timer = window.setTimeout(() => loadAppointments().catch((error) => showToast(error.message,true)),250);
});
$('#export-csv').addEventListener('click',() => { window.location.href='/api/appointments/export-csv'; });
$('#export-xlsx').addEventListener('click',() => { window.location.href='/api/appointments/export-excel'; });
$('#appointment-doctor').addEventListener('change',updateAppointmentServices);
$('#appointments-list').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-save-status]');
  if (!button) return;
  const id = button.dataset.saveStatus;
  const select = $(`[data-status-for="${CSS.escape(id)}"]`);
  if (!select) return;
  button.disabled = true;
  try {
    await api(`/api/appointments/${encodeURIComponent(id)}/status`,{method:'PUT',body:JSON.stringify({status:select.value})});
    showToast('Appointment status updated.');
    await loadAppointments();
  } catch (error) { showToast(error.message,true); }
  finally { button.disabled = false; }
});

$('#appointment-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget).entries());
  data.doctorId = Number(data.doctorId);
  data.serviceId = Number(data.serviceId);
  try {
    const result = await api('/api/appointments',{method:'POST',body:JSON.stringify(data)});
    $('#appointment-result').textContent = `Created appointment ${result.appointmentId}.`;
    event.currentTarget.reset();
    $('#appointment-doctor').value = String(state.doctors[0]?.id || '');
    updateAppointmentServices();
    await Promise.all([loadAppointments(),loadClients()]);
  } catch (error) { $('#appointment-result').textContent = error.message; }
});

$('#doctor-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget).entries());
  data.slot_duration_minutes = Number(data.slot_duration_minutes);
  try {
    const result = await api('/api/doctors',{method:'POST',body:JSON.stringify(data)});
    $('#doctor-result').textContent = result.initialPassword ? `Doctor added. Initial account password: ${result.initialPassword}` : 'Doctor added.';
    event.currentTarget.reset();
    await loadDoctors();
  } catch (error) { $('#doctor-result').textContent = error.message; }
});

$('#service-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget).entries());
  data.duration_minutes = Number(data.duration_minutes);
  data.price = Number(data.price);
  data.doctorId = data.doctorId ? Number(data.doctorId) : null;
  try {
    await api('/api/services',{method:'POST',body:JSON.stringify(data)});
    $('#service-result').textContent = 'Service added.';
    event.currentTarget.reset();
    await loadServices();
  } catch (error) { $('#service-result').textContent = error.message; }
});

$('#import-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const file = $('#patient-file').files[0];
  if (!file) return;
  const data = new FormData();
  data.append('file',file);
  try {
    const result = await api('/api/clients/import',{method:'POST',body:data});
    $('#import-result').textContent = `Imported ${result.importedCount} patient profile(s) for ${result.clientsCount} new contact(s).`;
    await loadClients();
  } catch (error) { $('#import-result').textContent = error.message; }
});

$('#download-template').addEventListener('click',() => { window.location.href='/api/clients/sample-template?format=xlsx'; });
$('#user-role').addEventListener('change',() => $('#user-doctor-field').classList.toggle('hidden',$('#user-role').value !== 'doctor'));
$('#user-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget).entries());
  data.doctorId = data.role === 'doctor' ? Number(data.doctorId) : null;
  try {
    const result = await api('/api/users',{method:'POST',body:JSON.stringify(data)});
    $('#users-result').textContent = `Account created for ${result.user.username}. One-time password: ${result.tempPassword}. Deliver it through a verified channel and require a change at sign-in.`;
    event.currentTarget.reset();
    $('#user-doctor-field').classList.add('hidden');
    await loadUsers();
  } catch (error) { $('#users-result').textContent = error.message; }
});
$('#refresh-users').addEventListener('click',() => loadUsers().catch((error) => showToast(error.message,true)));
$('#users-list').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-reset-user]');
  if (!button) return;
  const user = state.users.find((item) => Number(item.id) === Number(button.dataset.resetUser));
  if (!user || Number(user.id) === Number(state.user?.id)) return showToast('Use a second administrator account to reset your own password.',true);
  if (!window.confirm(`Generate a one-time password for ${user.full_name}?`)) return;
  button.disabled = true;
  try {
    const result = await api(`/api/users/${user.id}/reset-password`,{method:'POST',body:JSON.stringify({})});
    $('#users-result').textContent = `${result.message} Username: ${user.username}. One-time password: ${result.tempPassword}. Ask the user to change it at sign-in.`;
    showToast('One-time password generated. Share it only through a verified channel.');
  } catch (error) { $('#users-result').textContent = error.message; }
  finally { button.disabled = false; }
});

$('#settings-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget).entries());
  try {
    const result = await api('/api/settings',{method:'PUT',body:JSON.stringify(data)});
    state.settings = result.settings;
    $('#settings-result').textContent = 'Saved.';
    $('#clinic-name').textContent = state.settings.business_name || 'Your clinic';
  } catch (error) { $('#settings-result').textContent = error.message; }
});

(async function bootstrap() {
  try {
    const result = await api('/api/auth/me');
    showApp(result.user);
  } catch {
    showLogin();
  }
})();
