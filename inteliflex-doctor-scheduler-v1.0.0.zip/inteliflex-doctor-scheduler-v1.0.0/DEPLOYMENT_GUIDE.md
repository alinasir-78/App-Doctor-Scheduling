# INTELIFLEX single-clinic deployment guide

This package is designed for **one clinic per application instance**. INTELIFLEX may operate the infrastructure centrally; clinics do not need to run a server on their own website. The clinic supplies its scheduling details and its own Meta/WhatsApp business assets.

## Readiness and limits

The missing runtime has been rebuilt from this repository’s tests and deployment notes. The local source preflight and 12 controlled test suites pass, including production first-run bootstrap checks. The suites use temporary databases; the runner blanks Meta credentials.

No Docker image build, Render deployment, live Meta webhook exchange, or production clinic setup was performed in the coding sandbox. The tests are not a production security certification, HIPAA/BAA assessment, or approval to store identifiable patient information. Complete the clinic/vendor review and deployment validation below before using real data.

## Isolation model

- **One clinic = one app instance, SQLite file/data volume, environment/secrets set, hostname, and Meta credential set.** Never share a clinic database or WhatsApp access token with another clinic.
- Prefer a dedicated VM per clinic for machine-level isolation. Separate Compose projects, host directories, secrets, and domains on a shared VM are a lower-cost option, but the VM administrator and host remain shared trust boundaries.
- This is a multi-doctor, single-clinic application—not a multi-tenant clinic platform. Do not point multiple clinics at one app or SQLite file.
- Keep the clinic in control of its Meta business portfolio, WhatsApp Business Account, and messaging number. Plan migration/coexistence before connecting a number already used by WhatsApp Business.

## Intended topology

```text
Patients' WhatsApp
        ↕
Meta WhatsApp Business Cloud API
        ↕ signed HTTPS webhook
Clinic-specific INTELIFLEX app :3000
        ↕ clinic-specific persistent /data volume
Nginx HTTPS endpoint: https://<clinic-hostname>
```

The app’s container port should be reachable only through the trusted reverse proxy. The implemented webhook path is `/api/whatsapp/webhook`. Production verifies `X-Hub-Signature-256` using that clinic’s `META_APP_SECRET`.

## Requirements

- A supported Linux VM with Docker Engine and Docker Compose v2, or an equivalent managed container service with durable storage.
- A clinic-specific hostname and DNS pointing to that clinic’s service.
- Firewall access for SSH and public HTTPS only; do not expose port 3000 to the public internet.
- A clinic-owned Meta WhatsApp Cloud API setup and the phone-number ID, access token, verify token, app secret, and a currently supported Graph API version.
- A separate persistent storage target for every clinic. This application uses SQLite and is intended for one app process/replica per database file.

## Deploy one clinic with Compose

Create a separate directory for each clinic. Example:

```bash
sudo mkdir -p /opt/inteliflex
sudo chown -R "$USER":"$USER" /opt/inteliflex
git clone <repository-url> /opt/inteliflex/clinic-a
cd /opt/inteliflex/clinic-a
cp .env.example .env
chmod 600 .env
mkdir -p data
chmod 700 data
```

For another clinic, clone into a different directory such as `/opt/inteliflex/clinic-b`; do not reuse the first clinic’s `.env`, database, Meta IDs, access token, or backups.

Edit `.env` for this clinic only:

- Give `COMPOSE_PROJECT_NAME`, `CLINIC_INSTANCE_ID`, `CLINIC_NAME`, and `HOST_PORT` unique per-clinic values.
- Set `DATABASE_PATH=/data/doctor_agent.db` and `TRUST_PROXY=1` only when the app is behind the single trusted Nginx hop shown in the example.
- Supply this clinic’s `META_PHONE_NUMBER_ID`, `META_WABA_ID`, `META_ACCESS_TOKEN`, `META_VERIFY_TOKEN`, `META_APP_SECRET`, and a currently supported `META_GRAPH_API_VERSION`.
- For a fresh production database, set a unique `BOOTSTRAP_ADMIN_USERNAME`, `BOOTSTRAP_ADMIN_EMAIL`, and randomly generated `BOOTSTRAP_ADMIN_PASSWORD` of at least 16 characters. Keep the file or secret-manager values private; never put them in source control, a browser setting, or chat.

The initial production database receives **only** the administrator account and clinic settings; development doctors, patients, appointments, and sample passwords are not seeded. The administrator is required to change the bootstrap password on first sign-in. After confirming the first account works, remove `BOOTSTRAP_ADMIN_PASSWORD` from the runtime secret environment and recreate/redeploy the service as appropriate. A populated database will not bootstrap another default user.

Create the host data directory with ownership for the unprivileged `node` user (UID 1000 in the supplied image):

```bash
sudo chown -R 1000:1000 data
sudo chmod 700 data
```

The process applies a restrictive umask; newly created database/WAL files are private to the service account. A read-only container is used, with only the clinic data volume writable.

Build and start this clinic:

```bash
docker compose build
docker compose up -d
docker compose ps
docker compose logs -f app
```

Nginx on the VM proxies to the loopback port selected by `HOST_PORT`. Keep that port inaccessible from the public network. Use distinct Compose project names, host ports, data directories, and Nginx hostnames for each clinic sharing a VM.

After the first sign-in, complete clinic setup in the dashboard: configure business details and IANA timezone, add doctors and working schedules, add services and fees, and create staff accounts. New accounts receive a random one-time password which must be delivered only through a verified out-of-band channel and changed at first sign-in. Password reset is administrator-managed; there is no automatic self-service email reset delivery.

## DNS, Nginx, and TLS

Copy `deploy/nginx/inteliflex.conf.example` into `/etc/nginx/sites-available/<clinic-hostname>`, replace the example hostname, enable it, and validate:

```bash
sudo ln -s /etc/nginx/sites-available/<clinic-hostname> /etc/nginx/sites-enabled/<clinic-hostname>
sudo nginx -t
sudo systemctl reload nginx
```

Issue a TLS certificate after DNS resolves. Confirm `https://<clinic-hostname>` serves the app, `/healthz` reports healthy, and port 3000 is reachable only from the local reverse proxy. `TRUST_PROXY=1` is intended for exactly one trusted proxy hop; do not set it if untrusted clients can reach the app directly.

## Meta / WhatsApp activation

1. Use Meta’s official WhatsApp Business Cloud API; do not automate the consumer or Business app through a browser session.
2. Keep the clinic as owner of its WhatsApp Business Account and phone number. Store that clinic’s tokens only in its server-side secret environment.
3. Configure callback `https://<clinic-hostname>/api/whatsapp/webhook`, the exact `META_VERIFY_TOKEN`, and the subscribed `messages` webhook field.
4. Keep `META_APP_SECRET` configured so production verifies incoming webhook signatures. Do not disable signature checking to work around setup errors.
5. Use test numbers first. Verify inbound text, outbound replies, booking/confirmation, cancellations, reminders, opt-in/consent text, time-zone display, message failure handling, and Meta retry behavior before launch.
6. Recheck the supported Graph API version, Meta policies, and current messaging charges at deployment time. Meta prices and version support can change.

The shipped scheduler is text-based; it is not a voice-call agent. WhatsApp delivery is not guaranteed by passing the local tests: it must be validated against the clinic’s own Meta assets.

## Backups, privacy, and operations

- Keep each clinic’s SQLite database, encrypted backups, logs, and retention schedule separate. Restrict host access, test restores, monitor disk usage and `/healthz`, and document incident response and offboarding.
- Do not run multiple replicas against one SQLite file. Move to a database designed for multi-writer/high-availability workloads if this single-instance model no longer fits.
- Patient names, phone numbers, appointment details, and WhatsApp message logs are sensitive. Use synthetic data until the full data flow, access roles, vendor subprocessors, retention, and deletion process are reviewed.
- Do not claim HIPAA compliance or a BAA based only on the application or hosting configuration. Obtain legal/security review and the agreements and safeguards required for the actual data and vendors.
- The tracked root `doctor_agent.db` is excluded from the Docker build context but remains in Git history. **Never deploy it or use it as a clinic database.** Start with a fresh `/data/doctor_agent.db`; ignore rules do not erase historical copies from GitHub.

## Validation commands

For local checks with Node.js 22.9+:

```bash
npm ci
npm run build
npm test
npm audit
```

`npm run build` runs the deployment source preflight; it is not a container build. `npm test` uses isolated temporary SQLite files and blank Meta credentials. Docker and live Meta validation must still be run in the actual deployment environment.

## Optional Render template

`render.yaml` describes one paid service and one persistent disk. Create a separate service, disk, hostname, and secret set for every clinic. Check that the selected plan/region and disk behavior still match the provider’s current offering, set all `sync: false` environment variables, and verify `/healthz`. The template is not a substitute for the Compose isolation model or a successful live deployment test.
