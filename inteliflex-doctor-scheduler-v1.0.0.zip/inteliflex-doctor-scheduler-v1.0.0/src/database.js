'use strict';

const sqlite3 = require('sqlite3').verbose();
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

process.umask(0o077);

const rootDir = path.resolve(__dirname, '..');
const defaultDbPath = process.env.NODE_ENV === 'production'
  ? '/data/doctor_agent.db'
  : path.join(rootDir, 'data', 'doctor_agent.db');
const DB_PATH = path.resolve(process.env.DATABASE_PATH || defaultDbPath);
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true, mode: 0o700 });
for (const file of [DB_PATH, `${DB_PATH}-wal`, `${DB_PATH}-shm`]) {
  if (fs.existsSync(file)) fs.chmodSync(file, 0o600);
}

const db = new sqlite3.Database(DB_PATH);
db.configure('busyTimeout', 8000);
db.run('PRAGMA foreign_keys = ON');
db.run('PRAGMA journal_mode = WAL');
db.run('PRAGMA synchronous = NORMAL');

function rawRun(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function onRun(error) {
      if (error) return reject(error);
      resolve({ lastID: this.lastID, changes: this.changes });
    });
  });
}

function rawGet(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (error, row) => error ? reject(error) : resolve(row));
  });
}

function rawAll(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (error, rows) => error ? reject(error) : resolve(rows || []));
  });
}

let initPromise;
let closing = false;

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.pbkdf2Sync(String(password), String(salt), 160000, 64, 'sha512').toString('hex');
  return { hash, salt, password_hash: hash };
}

function verifyPassword(password, expectedHash, salt) {
  if (!expectedHash || !salt) return false;
  const actual = Buffer.from(hashPassword(password, salt).hash, 'hex');
  const expected = Buffer.from(expectedHash, 'hex');
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

const schema = [
  `CREATE TABLE IF NOT EXISTS doctors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    title TEXT NOT NULL DEFAULT 'Physician',
    specialty TEXT NOT NULL,
    personal_phone TEXT NOT NULL DEFAULT '',
    email TEXT,
    color_code TEXT DEFAULT '#2563eb',
    bio TEXT,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`,
  `CREATE TABLE IF NOT EXISTS doctor_schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    doctor_id INTEGER NOT NULL,
    day_of_week INTEGER NOT NULL,
    day_name TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    break_start TEXT NOT NULL DEFAULT '12:00',
    break_end TEXT NOT NULL DEFAULT '13:00',
    slot_duration_minutes INTEGER NOT NULL DEFAULT 30,
    buffer_minutes INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE,
    UNIQUE(doctor_id, day_of_week)
  )`,
  `CREATE TABLE IF NOT EXISTS doctor_unavailability (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    doctor_id INTEGER NOT NULL,
    date TEXT NOT NULL,
    start_time TEXT,
    end_time TEXT,
    is_full_day INTEGER NOT NULL DEFAULT 1,
    reason TEXT NOT NULL DEFAULT '',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE
  )`,
  `CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    doctor_id INTEGER,
    name TEXT NOT NULL,
    duration_minutes INTEGER NOT NULL,
    price REAL NOT NULL DEFAULT 0,
    description TEXT,
    is_active INTEGER NOT NULL DEFAULT 1,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE SET NULL
  )`,
  `CREATE TABLE IF NOT EXISTS clients (
    phone TEXT PRIMARY KEY,
    registered_name TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`,
  `CREATE TABLE IF NOT EXISTS patients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    client_phone TEXT NOT NULL,
    full_name TEXT NOT NULL,
    relationship TEXT NOT NULL DEFAULT 'Self',
    age_or_notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (client_phone) REFERENCES clients(phone) ON DELETE CASCADE,
    UNIQUE(client_phone, full_name)
  )`,
  `CREATE TABLE IF NOT EXISTS appointments (
    id TEXT PRIMARY KEY,
    doctor_id INTEGER NOT NULL,
    doctor_name TEXT NOT NULL,
    doctor_phone TEXT NOT NULL DEFAULT '',
    client_phone TEXT NOT NULL,
    patient_id INTEGER,
    patient_name TEXT NOT NULL,
    service_id INTEGER NOT NULL,
    service_name TEXT NOT NULL,
    date TEXT NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    fee REAL NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'confirmed' CHECK(status IN ('confirmed','tentative','completed','cancelled','no_show')),
    confirmation_sent_at DATETIME,
    confirmed_at DATETIME,
    cancelled_by TEXT,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id)
  )`,
  `CREATE TABLE IF NOT EXISTS chat_sessions (
    phone TEXT PRIMARY KEY,
    state TEXT DEFAULT 'IDLE',
    context_data TEXT DEFAULT '{}',
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`,
  `CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone TEXT NOT NULL,
    direction TEXT NOT NULL CHECK(direction IN ('inbound','outbound')),
    sender_name TEXT,
    message TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`,
  `CREATE TABLE IF NOT EXISTS owner_notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    doctor_id INTEGER,
    type TEXT NOT NULL,
    appointment_id TEXT,
    phone TEXT,
    message TEXT NOT NULL,
    is_read INTEGER NOT NULL DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`,
  `CREATE TABLE IF NOT EXISTS slot_holds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    doctor_id INTEGER NOT NULL,
    date TEXT NOT NULL,
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    held_by_phone TEXT NOT NULL,
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE
  )`,
  `CREATE TABLE IF NOT EXISTS auth_sessions (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    role TEXT NOT NULL,
    doctor_id INTEGER,
    expires_at DATETIME NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  )`,
  `CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    salt TEXT NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin','director','doctor','receptionist')),
    doctor_id INTEGER,
    is_active INTEGER NOT NULL DEFAULT 1,
    must_change_password INTEGER NOT NULL DEFAULT 0,
    permissions TEXT,
    last_login DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE SET NULL
  )`,
  `CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY CHECK(id = 1),
    business_name TEXT NOT NULL DEFAULT 'Clinic',
    business_type TEXT NOT NULL DEFAULT 'Medical Clinic',
    clinic_phone TEXT NOT NULL DEFAULT '',
    owner_personal_phone TEXT NOT NULL DEFAULT '',
    address TEXT NOT NULL DEFAULT '',
    persona_name TEXT NOT NULL DEFAULT 'Clinic Assistant',
    persona_tone TEXT NOT NULL DEFAULT 'professional and friendly',
    custom_instructions TEXT NOT NULL DEFAULT '',
    cancellation_policy TEXT NOT NULL DEFAULT '',
    whatsapp_phone_number_id TEXT NOT NULL DEFAULT '',
    whatsapp_verify_token TEXT NOT NULL DEFAULT '',
    whatsapp_access_token TEXT NOT NULL DEFAULT '',
    currency TEXT DEFAULT 'USD',
    currency_symbol TEXT DEFAULT '$',
    currency_position TEXT DEFAULT 'before',
    country TEXT DEFAULT 'Pakistan',
    country_code TEXT DEFAULT 'PK',
    timezone TEXT DEFAULT 'Asia/Karachi',
    timezone_label TEXT DEFAULT 'PKT (UTC+5)',
    sample_data_cleared INTEGER NOT NULL DEFAULT 0,
    sample_data_cleared_at TEXT DEFAULT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS meta_api_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    direction TEXT CHECK(direction IN ('inbound','outbound')),
    endpoint TEXT,
    recipient TEXT,
    status_code INTEGER,
    payload TEXT,
    response TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`,
  'CREATE INDEX IF NOT EXISTS idx_appointments_doctor_date_time ON appointments(doctor_id, date, start_time, end_time)',
  'CREATE INDEX IF NOT EXISTS idx_appointments_client ON appointments(client_phone, date)',
  'CREATE INDEX IF NOT EXISTS idx_holds_doctor_date ON slot_holds(doctor_id, date, expires_at)',
  'CREATE INDEX IF NOT EXISTS idx_users_doctor ON users(doctor_id)'
];

async function addUser({ username, email, password, fullName, role, doctorId = null, mustChangePassword = 1, permissions = [] }) {
  const salt = crypto.randomBytes(16).toString('hex');
  const passwordHash = hashPassword(password, salt).hash;
  await rawRun(
    `INSERT OR IGNORE INTO users (username,email,password_hash,salt,full_name,role,doctor_id,must_change_password,permissions)
     VALUES (?,?,?,?,?,?,?,?,?)`,
    [username, email, passwordHash, salt, fullName, role, doctorId, mustChangePassword, JSON.stringify(permissions)]
  );
}

async function seedDefaultSettings() {
  const current = await rawGet('SELECT id FROM settings WHERE id = 1');
  if (current) return;
  const clinicName = process.env.CLINIC_NAME || 'Clinic';
  await rawRun(
    `INSERT INTO settings (
      id,business_name,business_type,clinic_phone,owner_personal_phone,address,
      persona_name,persona_tone,custom_instructions,cancellation_policy,
      whatsapp_phone_number_id,whatsapp_verify_token,whatsapp_access_token,
      currency,currency_symbol,currency_position,country,country_code,timezone,timezone_label
    ) VALUES (1,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    [clinicName, 'Medical Clinic', '', '', '', 'Clinic Assistant', 'professional and friendly', '', '', '', '', '', 'USD', '$', 'before', 'Pakistan', 'PK', 'Asia/Karachi', 'PKT (UTC+5)']
  );
}

async function seedDevelopmentData() {
  const settings = await rawGet('SELECT sample_data_cleared FROM settings WHERE id=1');
  if (settings?.sample_data_cleared) return;
  const countRow = await rawGet('SELECT COUNT(*) AS count FROM doctors');
  if (countRow.count === 0) {
    const defaultDoctors = [
      { name: 'Dr. Alexander Wright, MD', title: 'Cardiologist', specialty: 'Cardiology & Internal Medicine', phone: '+1 (555) 301-4401', email: 'dr.wright@example.test', color: '#2563eb' },
      { name: 'Dr. Sophia Patel, MD', title: 'Pediatrician', specialty: 'Pediatrics', phone: '+1 555 018 7711', email: 'dr.patel@example.test', color: '#7c3aed' },
      { name: 'Dr. Marcus Vance, DO', title: 'Family Physician', specialty: 'Family Medicine', phone: '+1 555 018 7722', email: 'dr.vance@example.test', color: '#059669' }
    ];
    for (const [index, doctor] of defaultDoctors.entries()) {
      const result = await rawRun(
        'INSERT INTO doctors (name,title,specialty,personal_phone,email,color_code) VALUES (?,?,?,?,?,?)',
        [doctor.name, doctor.title, doctor.specialty, doctor.phone, doctor.email, doctor.color]
      );
      const doctorId = result.lastID;
      for (let day = 0; day < 7; day++) {
        const dayName = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][day];
        const active = day >= 1 && day <= 5 ? 1 : 0;
        await rawRun(
          `INSERT INTO doctor_schedules (doctor_id,day_of_week,day_name,is_active,start_time,end_time,break_start,break_end,slot_duration_minutes,buffer_minutes)
           VALUES (?,?,?,?,?,?,?,?,?,?)`,
          [doctorId, day, dayName, active, '09:00', '17:00', '12:00', '13:00', index === 0 ? 45 : 30, 0]
        );
      }
    }
  }

  const serviceCount = await rawGet('SELECT COUNT(*) AS count FROM services');
  if (serviceCount.count === 0) {
    const defaultServices = [
      [null, 'Cardiology Consultation', 45, 120, 'Initial or follow-up cardiology consultation'],
      [null, 'Pediatric Checkup', 30, 95, 'General pediatric visit'],
      [null, 'Family Medicine Consultation', 30, 80, 'Primary care visit']
    ];
    for (const item of defaultServices) {
      await rawRun('INSERT INTO services (doctor_id,name,duration_minutes,price,description) VALUES (?,?,?,?,?)', item);
    }
  }

  const userCount = await rawGet('SELECT COUNT(*) AS count FROM users');
  if (userCount.count === 0) {
    await addUser({ username: 'admin', email: 'admin@example.test', password: 'Admin@2026!', fullName: 'Clinic Administrator', role: 'admin', mustChangePassword: 1 });
    await addUser({ username: 'director', email: 'director@example.test', password: 'Director@2026!', fullName: 'Medical Director', role: 'director', mustChangePassword: 1 });
    await addUser({ username: 'reception', email: 'reception@example.test', password: 'Password123!', fullName: 'Front Desk Reception', role: 'receptionist', mustChangePassword: 1 });
    const doctors = await rawAll('SELECT id,name,email FROM doctors ORDER BY id');
    const doctorUsers = [
      ['dr.wright', 'dr.wright@example.test', 'DoctorPass@2026!', doctors[0]],
      ['dr.patel', 'dr.patel@example.test', 'DoctorPass@2026!', doctors[1]],
      ['dr.vance', 'dr.vance@example.test', 'DoctorPass@2026!', doctors[2]]
    ];
    for (const [username,email,password,doctor] of doctorUsers) {
      if (doctor) await addUser({ username, email, password, fullName: doctor.name, role: 'doctor', doctorId: doctor.id, mustChangePassword: 1 });
    }
  }
}

async function seedProductionAdmin() {
  const userCount = await rawGet('SELECT COUNT(*) AS count FROM users');
  if (userCount.count > 0) return;
  const username = String(process.env.BOOTSTRAP_ADMIN_USERNAME || '').trim();
  const password = String(process.env.BOOTSTRAP_ADMIN_PASSWORD || '');
  const email = String(process.env.BOOTSTRAP_ADMIN_EMAIL || '').trim();
  if (!username || password.length < 16 || !email) {
    throw new Error('Fresh production database requires BOOTSTRAP_ADMIN_USERNAME, BOOTSTRAP_ADMIN_EMAIL, and a unique BOOTSTRAP_ADMIN_PASSWORD of at least 16 characters. Set them in the secret manager, start once, then remove the bootstrap password from the runtime environment.');
  }
  await addUser({ username, email, password, fullName: 'Clinic Administrator', role: 'admin', mustChangePassword: 1 });
}

async function initDb() {
  if (closing) throw new Error('Database is closing');
  if (!initPromise) {
    initPromise = (async () => {
      for (const statement of schema) await rawRun(statement);
      await seedDefaultSettings();
      if (process.env.NODE_ENV === 'production') await seedProductionAdmin();
      else await seedDevelopmentData();
      await rawRun("DELETE FROM slot_holds WHERE expires_at <= datetime('now')");
    })().catch((error) => {
      initPromise = null;
      throw error;
    });
  }
  return initPromise;
}

async function runQuery(sql, params = []) {
  await initDb();
  return rawRun(sql, params);
}

async function getQuery(sql, params = []) {
  await initDb();
  return rawGet(sql, params);
}

async function allQuery(sql, params = []) {
  await initDb();
  return rawAll(sql, params);
}

function validTimeZone(timezone) {
  try { new Intl.DateTimeFormat('en-US', { timeZone: timezone }).format(new Date()); return timezone; }
  catch { return 'Asia/Karachi'; }
}

function getClinicDateTime(timezone = 'Asia/Karachi', now = new Date()) {
  const zone = validTimeZone(timezone);
  const formatter = new Intl.DateTimeFormat('en-GB', {
    timeZone: zone,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
  });
  const parts = Object.fromEntries(formatter.formatToParts(now).map((part) => [part.type, part.value]));
  const tzPart = new Intl.DateTimeFormat('en-US', { timeZone: zone, timeZoneName: 'short' })
    .formatToParts(now).find((part) => part.type === 'timeZoneName');
  return {
    dateStr: `${parts.year}-${parts.month}-${parts.day}`,
    timeStr: `${parts.hour}:${parts.minute}`,
    timezone: zone,
    tzAbbr: tzPart ? tzPart.value : zone,
    timezoneLabel: tzPart ? tzPart.value : zone
  };
}

async function getClinicNow() {
  await initDb();
  const settings = await rawGet('SELECT timezone, timezone_label FROM settings WHERE id = 1');
  const info = getClinicDateTime(settings?.timezone || 'Asia/Karachi');
  return { ...info, timezoneLabel: settings?.timezone_label || info.timezoneLabel };
}

function getDateOffset(days = 0, timezone = 'Asia/Karachi') {
  const now = getClinicDateTime(timezone);
  const date = new Date(`${now.dateStr}T12:00:00.000Z`);
  date.setUTCDate(date.getUTCDate() + Number(days || 0));
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth()+1).padStart(2,'0')}-${String(date.getUTCDate()).padStart(2,'0')}`;
}

function closeDb() {
  if (closing) return Promise.resolve();
  closing = true;
  return new Promise((resolve, reject) => db.close((error) => error ? reject(error) : resolve()));
}

module.exports = {
  db, DB_PATH, initDb, runQuery, getQuery, allQuery,
  hashPassword, verifyPassword, getClinicDateTime, getClinicNow, getDateOffset, closeDb
};
