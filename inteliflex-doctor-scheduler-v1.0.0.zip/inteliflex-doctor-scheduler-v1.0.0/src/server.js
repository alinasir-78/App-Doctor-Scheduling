'use strict';

const crypto = require('node:crypto');
const path = require('node:path');
const fs = require('node:fs');
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const ExcelJS = require('exceljs');
const {
  initDb, getQuery, allQuery, runQuery, hashPassword, verifyPassword,
  getClinicNow, closeDb
} = require('./database');
const { getAvailableDoctorSlots, checkSlotConflict, formatTime12, withSlotReservationLock } = require('./slotManager');
const { processIncomingMessage } = require('./aiAgent');
const { runConfirmationCheck } = require('./reminderScheduler');
const { getWhatsAppConfig, verifyWebhookSignature, sendWhatsAppMessage, extractTextMessages } = require('./whatsappService');

const app = express();
const isProduction = process.env.NODE_ENV === 'production';
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024, files: 1 } });
const PERMISSIONS = [
  'calendar_view','calendar_manage','calendar_all_doctors',
  'doctors_view','doctors_manage','unavailability_view','unavailability_manage',
  'appointments_view','appointments_manage','appointments_cancel',
  'clients_view','clients_manage','pricing_view',
  'settings_manage','users_manage'
];

app.disable('x-powered-by');
app.set('trust proxy', process.env.TRUST_PROXY === '1' ? 1 : false);
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'");
  res.setHeader('Cache-Control', req.path.startsWith('/api/') ? 'no-store' : 'no-cache');
  next();
});
const allowedOrigins = (process.env.CORS_ORIGINS || '').split(',').map((x) => x.trim()).filter(Boolean);
// Same-origin dashboard requests do not need CORS. Only enable cross-origin
// access when an explicit origin allowlist is configured.
if (allowedOrigins.length) {
  app.use(cors({
    origin(origin, callback) {
      if (!origin || allowedOrigins.includes(origin)) return callback(null, true);
      return callback(new Error('Origin not allowed'));
    },
    credentials: true,
    allowedHeaders: ['Content-Type','Authorization','X-Requested-With'],
    methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS']
  }));
}
app.use(express.json({
  limit: '1mb',
  verify(req, res, buffer) { req.rawBody = Buffer.from(buffer); }
}));
app.use(express.urlencoded({ extended: false, limit: '1mb' }));

function sendError(res, status, error) {
  return res.status(status).json({ success: false, error });
}

function cookieValue(req, name) {
  const cookies = String(req.headers.cookie || '').split(';');
  const prefix = `${name}=`;
  const item = cookies.map((value) => value.trim()).find((value) => value.startsWith(prefix));
  if (!item) return '';
  try { return decodeURIComponent(item.slice(prefix.length)); } catch { return ''; }
}

function requestToken(req) {
  const authHeader = String(req.headers.authorization || '');
  if (/^Bearer\s+/i.test(authHeader)) return authHeader.replace(/^Bearer\s+/i, '').trim();
  const cookie = cookieValue(req, 'inteliflex_session');
  if (cookie) return cookie;
  if (!isProduction && req.query.token) return String(req.query.token);
  return '';
}

function tokenDigest(token) {
  return crypto.createHash('sha256').update(String(token)).digest('hex');
}

async function lookupUser(req) {
  const token = requestToken(req);
  if (!token) return null;
  const digest = tokenDigest(token);
  const row = await getQuery(
    `SELECT u.id,u.username,u.email,u.full_name,u.role,u.doctor_id,u.is_active,
            u.must_change_password,u.permissions,s.token
     FROM auth_sessions s JOIN users u ON u.id=s.user_id
     WHERE s.token=? AND s.expires_at > CURRENT_TIMESTAMP AND u.is_active=1`,
    [digest]
  );
  if (!row) return null;
  try { row.permissionList = JSON.parse(row.permissions || '[]'); } catch { row.permissionList = []; }
  return row;
}

function authenticate({ devAdmin = false, roles = null } = {}) {
  return async (req, res, next) => {
    try {
      const hasCredential = Boolean(requestToken(req));
      const user = await lookupUser(req);
      if (user) {
        if (roles && !roles.includes(user.role)) return sendError(res, 403, 'You do not have permission to perform this action.');
        if (user.must_change_password && !['/api/auth/me','/api/auth/change-password','/api/auth/logout'].includes(req.path)) {
          return sendError(res,403,'Change your password before continuing.');
        }
        req.user = user;
        return next();
      }
      if (hasCredential) return sendError(res, 401, 'Session is invalid or has expired. Please sign in again.');
      if (devAdmin && !isProduction) {
        req.user = { id: 0, username: 'local-developer', full_name: 'Local Developer', role: 'admin', doctor_id: null, permissionList: PERMISSIONS };
        return next();
      }
      return sendError(res, 401, 'Authentication required.');
    } catch (error) {
      console.error('Authentication error:', error.message);
      return sendError(res, 500, 'Authentication could not be completed.');
    }
  };
}

const requireAdmin = authenticate({ roles: ['admin','director'] });
const adminOrDev = authenticate({ devAdmin: true, roles: ['admin','director'] });
const staffOrDev = authenticate({ devAdmin: true, roles: ['admin','director','receptionist'] });
const receptionistOrAbove = authenticate({ roles: ['admin','director','receptionist'] });

function cookieOptions() {
  const bits = ['Path=/', 'HttpOnly', 'SameSite=Strict', 'Max-Age=43200'];
  if (isProduction) bits.push('Secure');
  return bits.join('; ');
}

function clearSessionCookie(res) {
  const bits = ['Path=/', 'HttpOnly', 'SameSite=Strict', 'Max-Age=0'];
  if (isProduction) bits.push('Secure');
  res.setHeader('Set-Cookie', `inteliflex_session=; ${bits.join('; ')}`);
}

function makeSessionCookie(res, token) {
  res.setHeader('Set-Cookie', `inteliflex_session=${encodeURIComponent(token)}; ${cookieOptions()}`);
}

function cleanSettings(row) {
  if (!row) return {};
  const { whatsapp_access_token, whatsapp_verify_token, ...safe } = row;
  return safe;
}

function userPayload(user, doctorProfile = null) {
  return {
    id: user.id,
    username: user.username,
    email: user.email,
    fullName: user.full_name,
    full_name: user.full_name,
    role: user.role,
    doctorId: user.doctor_id,
    doctor_id: user.doctor_id,
    is_active: user.is_active,
    must_change_password: user.must_change_password,
    doctorProfile
  };
}

async function profileForUser(user) {
  if (!user.doctor_id) return null;
  return getQuery('SELECT id,name,title,specialty,personal_phone,email,color_code,bio,is_active FROM doctors WHERE id=?', [user.doctor_id]);
}

async function authenticatePassword(username, password) {
  const user = await getQuery('SELECT * FROM users WHERE lower(username)=lower(?) OR lower(email)=lower(?) LIMIT 1', [username, username]);
  if (!user) return { ok: false, error: 'Invalid username or password.' };
  if (!user.is_active) return { ok: false, status: 403, error: 'This user account is deactivated.' };
  if (!verifyPassword(password, user.password_hash, user.salt)) return { ok: false, error: 'Invalid username or password.' };
  const token = crypto.randomBytes(32).toString('base64url');
  const expiresAt = new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString().replace('T',' ').slice(0,19);
  await runQuery('INSERT INTO auth_sessions (token,user_id,role,doctor_id,expires_at) VALUES (?,?,?,?,?)', [tokenDigest(token), user.id, user.role, user.doctor_id, expiresAt]);
  await runQuery('UPDATE users SET last_login=CURRENT_TIMESTAMP WHERE id=?', [user.id]);
  const updatedUser = await getQuery('SELECT * FROM users WHERE id=?', [user.id]);
  const doctorProfile = await profileForUser(updatedUser);
  return { ok: true, token, user: userPayload(updatedUser, doctorProfile) };
}

function normalizePhone(value) {
  const raw = String(value || '').trim();
  const digits = raw.replace(/\D/g, '');
  return raw.startsWith('+') ? `+${digits}` : digits;
}

function csvEscape(value) {
  const text = String(value ?? '');
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function makeCsv(rows, columns) {
  const lines = [columns.map((column) => csvEscape(column.label)).join(',')];
  for (const row of rows) lines.push(columns.map((column) => csvEscape(row[column.key])).join(','));
  return `\uFEFF${lines.join('\r\n')}\r\n`;
}

function parseCsv(text) {
  const input = String(text || '').replace(/^\uFEFF/, '');
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;
  for (let index = 0; index < input.length; index++) {
    const char = input[index];
    if (quoted) {
      if (char === '"' && input[index + 1] === '"') { field += '"'; index++; }
      else if (char === '"') quoted = false;
      else field += char;
    } else if (char === '"') quoted = true;
    else if (char === ',') { row.push(field); field = ''; }
    else if (char === '\n') { row.push(field.replace(/\r$/, '')); rows.push(row); row = []; field = ''; }
    else field += char;
  }
  if (field.length || row.length) { row.push(field.replace(/\r$/, '')); rows.push(row); }
  return rows;
}

async function matrixFromExcelBuffer(buffer) {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(buffer);
  const worksheet = workbook.worksheets[0];
  if (!worksheet) return [];
  if (worksheet.rowCount > 2001 || worksheet.columnCount > 32) throw new Error('Spreadsheet exceeds the patient import row or column limit.');
  const matrix = [];
  worksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
    const values = [];
    row.eachCell({ includeEmpty: true }, (cell, columnNumber) => {
      values[columnNumber - 1] = cell.text || '';
    });
    matrix[rowNumber - 1] = values;
  });
  return matrix.filter(Boolean);
}

function samplePatientRows() {
  return [
    ['Mobile Number','Account Holder Name','Patient Full Name','Relationship','Age or DOB','Gender','Medical Notes / History'],
    ['+15550000001','Example Account Holder','Example Patient','Self','35','Prefer not to say',''],
    ['+15550000001','Example Account Holder','Example Family Member','Child','8','Prefer not to say','']
  ];
}

function toObjects(matrix) {
  if (!matrix || matrix.length < 2) return [];
  const headers = matrix[0].map((value) => String(value || '').trim().toLowerCase());
  const indexOf = (needle) => headers.findIndex((header) => header === needle.toLowerCase());
  const indices = {
    phone: indexOf('Mobile Number'),
    account: indexOf('Account Holder Name'),
    name: indexOf('Patient Full Name'),
    relationship: indexOf('Relationship'),
    age: indexOf('Age or DOB'),
    notes: indexOf('Medical Notes / History')
  };
  const phoneIndex = indices.phone >= 0 ? indices.phone : headers.findIndex((h) => /mobile|phone/.test(h));
  const nameIndex = indices.name >= 0 ? indices.name : headers.findIndex((h) => /patient.*name|full name/.test(h));
  return matrix.slice(1).filter((values) => values.some((value) => String(value || '').trim())).map((values) => ({
    phone: normalizePhone(values[phoneIndex]),
    accountName: String(values[indices.account >= 0 ? indices.account : nameIndex] || '').trim(),
    fullName: String(values[nameIndex] || '').trim(),
    relationship: String(values[indices.relationship] || 'Self').trim() || 'Self',
    ageOrNotes: [values[indices.age], values[indices.notes]].filter(Boolean).map(String).join(' — ')
  })).filter((item) => item.phone && item.fullName);
}

async function buildAppointmentRows(search = '') {
  let rows = await allQuery('SELECT * FROM appointments ORDER BY date DESC,start_time DESC');
  if (search) {
    const term = String(search).toLowerCase();
    rows = rows.filter((row) => [row.id,row.patient_name,row.client_phone,row.doctor_name,row.service_name].some((value) => String(value || '').toLowerCase().includes(term)));
  }
  return rows;
}

async function getDoctorsForApi(user = null) {
  const columns = 'id,name,title,specialty,color_code,bio,is_active,created_at';
  let doctors;
  if (user?.role === 'doctor') {
    if (!user.doctor_id) return [];
    doctors = await allQuery(`SELECT ${columns} FROM doctors WHERE id=? ORDER BY id`, [user.doctor_id]);
  } else {
    doctors = await allQuery(`SELECT ${columns} FROM doctors ORDER BY id`);
  }
  if (user && ['admin','director','receptionist'].includes(user.role)) {
    return Promise.all(doctors.map(async (doctor) => {
      const detail = await getQuery('SELECT personal_phone,email FROM doctors WHERE id=?', [doctor.id]);
      return { ...doctor, ...detail };
    }));
  }
  return doctors;
}

async function createDoctor(body) {
  const name = String(body.name || '').trim();
  const specialty = String(body.specialty || '').trim();
  if (!name || !specialty) throw Object.assign(new Error('Doctor name and specialty are required.'), { status: 400 });
  const title = String(body.title || 'Physician').trim();
  const phone = String(body.personal_phone || '').trim();
  const email = String(body.email || '').trim();
  const result = await runQuery(
    'INSERT INTO doctors (name,title,specialty,personal_phone,email,color_code,bio) VALUES (?,?,?,?,?,?,?)',
    [name,title,specialty,phone,email || null,body.color_code || '#2563eb',body.bio || '']
  );
  const doctorId = result.lastID;
  const days = body.working_days ? String(body.working_days).split(',').map((v) => Number(v.trim())) : [0,1,2,3,4,5,6];
  const start = body.day_start_time || '09:00';
  const end = body.day_end_time || '17:00';
  for (let day = 0; day < 7; day++) {
    await runQuery(
      `INSERT INTO doctor_schedules (doctor_id,day_of_week,day_name,is_active,start_time,end_time,break_start,break_end,slot_duration_minutes,buffer_minutes)
       VALUES (?,?,?,?,?,?,?,?,?,?)`,
      [doctorId,day,['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][day],days.includes(day) ? 1 : 0,start,end,body.break_start || '12:00',body.break_end || '13:00',Number(body.slot_duration_minutes) || 30,Number(body.buffer_minutes) || 0]
    );
  }

  const usernameBase = `dr.${name.toLowerCase().replace(/[^a-z0-9]+/g,'.').replace(/^\.|\.$/g,'').replace(/^dr\./,'')}`;
  let username = usernameBase || `doctor.${doctorId}`;
  let suffix = 1;
  while (await getQuery('SELECT id FROM users WHERE username=?', [username])) username = `${usernameBase}.${suffix++}`;
  const doctorEmail = email || `${username.replace(/[^a-z0-9.]/g,'')}.clinic@example.test`;
  const password = isProduction ? crypto.randomBytes(18).toString('base64url') : 'DoctorPass@2026!';
  const salt = crypto.randomBytes(16).toString('hex');
  const passwordHash = hashPassword(password,salt).hash;
  await runQuery(
    'INSERT INTO users (username,email,password_hash,salt,full_name,role,doctor_id,is_active,must_change_password,permissions) VALUES (?,?,?,?,?,?,?,1,1,?)',
    [username,doctorEmail,passwordHash,salt,name,'doctor',doctorId,JSON.stringify(['calendar_view','appointments_view','appointments_manage','unavailability_view','unavailability_manage'])]
  );
  const doctor = await getQuery('SELECT * FROM doctors WHERE id=?', [doctorId]);
  return { doctorId, doctor, initialPassword: isProduction ? password : undefined };
}

async function updateDoctor(doctorId, body) {
  const current = await getQuery('SELECT * FROM doctors WHERE id=?', [doctorId]);
  if (!current) throw Object.assign(new Error('Doctor not found.'), { status: 404 });
  const next = {
    name: body.name ?? current.name,
    title: body.title ?? current.title,
    specialty: body.specialty ?? current.specialty,
    personal_phone: body.personal_phone ?? current.personal_phone,
    email: body.email ?? current.email,
    color_code: body.color_code ?? current.color_code,
    bio: body.bio ?? current.bio,
    is_active: body.is_active === undefined ? current.is_active : (Number(body.is_active) ? 1 : 0)
  };
  await runQuery(
    `UPDATE doctors SET name=?,title=?,specialty=?,personal_phone=?,email=?,color_code=?,bio=?,is_active=? WHERE id=?`,
    [next.name,next.title,next.specialty,next.personal_phone,next.email,next.color_code,next.bio,next.is_active,doctorId]
  );
  if (body.working_days !== undefined) {
    const days = String(body.working_days).split(',').map((value) => Number(value.trim()));
    for (let day = 0; day < 7; day++) await runQuery('UPDATE doctor_schedules SET is_active=? WHERE doctor_id=? AND day_of_week=?', [days.includes(day) ? 1 : 0,doctorId,day]);
  }
  if (body.day_start_time || body.day_end_time || body.slot_duration_minutes || body.buffer_minutes) {
    const scheduleRows = await allQuery('SELECT id FROM doctor_schedules WHERE doctor_id=?', [doctorId]);
    for (const row of scheduleRows) {
      await runQuery('UPDATE doctor_schedules SET start_time=COALESCE(?,start_time),end_time=COALESCE(?,end_time),slot_duration_minutes=COALESCE(?,slot_duration_minutes),buffer_minutes=COALESCE(?,buffer_minutes) WHERE id=?', [body.day_start_time || null,body.day_end_time || null,body.slot_duration_minutes || null,body.buffer_minutes ?? null,row.id]);
    }
  }
  if (next.is_active === 0) {
    await runQuery('UPDATE users SET is_active=0 WHERE doctor_id=?', [doctorId]);
    await runQuery('DELETE FROM auth_sessions WHERE doctor_id=?', [doctorId]);
    if (body.cancelAppointments) await cancelDoctorAppointments(doctorId);
  } else {
    await runQuery('UPDATE users SET is_active=1 WHERE doctor_id=?', [doctorId]);
  }
  const updated = await getQuery('SELECT * FROM doctors WHERE id=?', [doctorId]);
  return updated;
}

async function cancelDoctorAppointments(doctorId) {
  const appointments = await allQuery("SELECT * FROM appointments WHERE doctor_id=? AND status IN ('confirmed','tentative')", [doctorId]);
  for (const appointment of appointments) {
    await runQuery("UPDATE appointments SET status='cancelled',cancelled_by='clinic' WHERE id=?", [appointment.id]);
    const message = `We’re sorry. Your appointment with ${appointment.doctor_name} on ${appointment.date} at ${formatTime12(appointment.start_time)} is no longer available with our clinic. Please contact the front desk to reschedule.`;
    await runQuery('INSERT INTO messages (phone,direction,sender_name,message) VALUES (?,?,?,?)', [appointment.client_phone,'outbound','Clinic',message]);
    await sendWhatsAppMessage(appointment.client_phone,message);
  }
  return appointments.length;
}

async function toggleDoctor(doctorId, cancelAppointments = false) {
  const doctor = await getQuery('SELECT * FROM doctors WHERE id=?', [doctorId]);
  if (!doctor) throw Object.assign(new Error('Doctor not found.'), { status: 404 });
  const nextStatus = doctor.is_active ? 0 : 1;
  await runQuery('UPDATE doctors SET is_active=? WHERE id=?', [nextStatus,doctorId]);
  await runQuery('UPDATE users SET is_active=? WHERE doctor_id=?', [nextStatus,doctorId]);
  if (!nextStatus) await runQuery('DELETE FROM auth_sessions WHERE doctor_id=?', [doctorId]);
  const cancelledCount = !nextStatus && cancelAppointments ? await cancelDoctorAppointments(doctorId) : 0;
  return { success: true, is_active: nextStatus, cancelledCount };
}

async function createAppointment(body) {
  return withSlotReservationLock(async () => {
  const doctorId = Number(body.doctorId || body.doctor_id);
  const serviceId = Number(body.serviceId || body.service_id);
  const phone = normalizePhone(body.clientPhone || body.client_phone);
  const patientName = String(body.patientName || body.clientName || body.patient_name || '').trim();
  const date = String(body.date || '').trim();
  const startTime = String(body.startTime || body.start_time || '').trim();
  if (!doctorId || !serviceId || !phone || !patientName || !date || !/^\d{2}:\d{2}$/.test(startTime)) {
    throw Object.assign(new Error('Doctor, service, patient, phone, date, and a valid start time are required.'), { status: 400 });
  }
  const doctor = await getQuery('SELECT * FROM doctors WHERE id=? AND is_active=1', [doctorId]);
  const service = await getQuery('SELECT * FROM services WHERE id=? AND is_active=1', [serviceId]);
  if (!doctor || !service) throw Object.assign(new Error('Doctor or service was not found.'), { status: 404 });
  if (service.doctor_id && Number(service.doctor_id) !== doctorId) throw Object.assign(new Error('This service is not available with the selected doctor.'), { status: 400 });
  const duration = Number(service.duration_minutes) || 30;
  const startMinutes = Number(startTime.slice(0,2))*60 + Number(startTime.slice(3,5));
  const endTime = `${String(Math.floor((startMinutes+duration)/60)).padStart(2,'0')}:${String((startMinutes+duration)%60).padStart(2,'0')}`;
  const conflict = await checkSlotConflict(doctorId,date,startTime,endTime,phone);
  if (conflict.conflict) {
    if (conflict.type === 'hold') throw Object.assign(new Error('This slot is held by a patient on WhatsApp.'), { status: 409 });
    if (conflict.type === 'past_date' || conflict.type === 'past_time') throw Object.assign(new Error('Past dates or times cannot be booked.'), { status: 400 });
    throw Object.assign(new Error('This time slot is no longer available.'), { status: 409 });
  }
  const availability = await getAvailableDoctorSlots(doctorId,date);
  const validSlot = availability.slots.find((slot) => slot.startTime === startTime && slot.endTime === endTime);
  if (!validSlot) throw Object.assign(new Error(availability.reason || 'That time is outside the doctor’s schedule or already booked.'), { status: 409 });

  const clientName = String(body.accountHolderName || body.clientName || patientName).trim();
  await runQuery('INSERT INTO clients (phone,registered_name) VALUES (?,?) ON CONFLICT(phone) DO UPDATE SET registered_name=excluded.registered_name', [phone,clientName]);
  await runQuery('INSERT OR IGNORE INTO patients (client_phone,full_name,relationship) VALUES (?,?,?)', [phone,patientName,body.relationship || 'Self']);
  const patient = await getQuery('SELECT * FROM patients WHERE client_phone=? AND full_name=?', [phone,patientName]);
  const appointmentId = `APT-${Date.now()}${Math.floor(Math.random()*900+100)}`;
  const result = await runQuery(
    `INSERT INTO appointments (id,doctor_id,doctor_name,doctor_phone,client_phone,patient_id,patient_name,service_id,service_name,date,start_time,end_time,fee,status,notes)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'confirmed',?)`,
    [appointmentId,doctorId,doctor.name,doctor.personal_phone || '',phone,patient?.id || null,patientName,serviceId,service.name,date,startTime,endTime,Number(service.price)||0,body.notes || '']
  );
  if (!result.changes) throw new Error('Appointment could not be saved.');
  const appointment = await getQuery('SELECT * FROM appointments WHERE id=?', [appointmentId]);
  return { success: true, appointmentId, appointment };
  });
}

async function listAppointments(search = '') {
  let rows = await allQuery('SELECT * FROM appointments ORDER BY date DESC,start_time DESC');
  if (search) {
    const value = String(search).toLowerCase();
    rows = rows.filter((row) => [row.id,row.patient_name,row.client_phone,row.doctor_name,row.service_name].some((x) => String(x || '').toLowerCase().includes(value)));
  }
  return rows;
}

async function listClients() {
  const clients = await allQuery('SELECT * FROM clients ORDER BY created_at DESC');
  return Promise.all(clients.map(async (client) => ({
    ...client,
    patients: await allQuery('SELECT * FROM patients WHERE client_phone=? ORDER BY id', [client.phone])
  })));
}

async function importPatientRows(rows) {
  let importedCount = 0;
  const newPhones = new Set();
  for (const item of rows) {
    const existing = await getQuery('SELECT phone FROM clients WHERE phone=?', [item.phone]);
    if (!existing) newPhones.add(item.phone);
    await runQuery('INSERT INTO clients (phone,registered_name) VALUES (?,?) ON CONFLICT(phone) DO UPDATE SET registered_name=CASE WHEN excluded.registered_name<>\'\' THEN excluded.registered_name ELSE clients.registered_name END', [item.phone,item.accountName || item.fullName]);
    const result = await runQuery('INSERT OR IGNORE INTO patients (client_phone,full_name,relationship,age_or_notes) VALUES (?,?,?,?)', [item.phone,item.fullName,item.relationship,item.ageOrNotes || '']);
    if (result.changes) importedCount++;
  }
  return { importedCount, clientsCount: newPhones.size };
}

async function purgeDemoData() {
  const settings = await getQuery('SELECT sample_data_cleared FROM settings WHERE id=1');
  if (settings?.sample_data_cleared) throw Object.assign(new Error('Initial sample data has already been purged and cannot be repeated.'), { status: 400 });
  const counts = {};
  for (const table of ['appointments','patients','clients','doctors','doctor_schedules','doctor_unavailability','slot_holds','chat_sessions','messages','owner_notifications']) {
    const row = await getQuery(`SELECT COUNT(*) AS count FROM ${table}`);
    counts[table] = row?.count || 0;
  }
  await runQuery('BEGIN IMMEDIATE');
  try {
    await runQuery('DELETE FROM appointments');
    await runQuery('DELETE FROM slot_holds');
    await runQuery('DELETE FROM doctor_unavailability');
    await runQuery('DELETE FROM doctor_schedules');
    await runQuery('DELETE FROM doctors');
    await runQuery('DELETE FROM patients');
    await runQuery('DELETE FROM clients');
    await runQuery('DELETE FROM chat_sessions');
    await runQuery('DELETE FROM messages');
    await runQuery('DELETE FROM owner_notifications');
    await runQuery("UPDATE settings SET sample_data_cleared=1,sample_data_cleared_at=CURRENT_TIMESTAMP WHERE id=1");
    await runQuery('COMMIT');
  } catch (error) {
    try { await runQuery('ROLLBACK'); } catch {}
    throw error;
  }
  return { success: true, message: 'Sample data purged. The clinic database is in production mode.', purged: { doctors: counts.doctors, patients: counts.patients, appointments: counts.appointments, clients: counts.clients } };
}

// Health and static dashboard
app.get('/healthz', async (req, res) => {
  try { await getQuery('SELECT 1 AS ok'); res.json({ ok: true, service: 'inteliflex-doctor-scheduler' }); }
  catch { res.status(503).json({ ok: false }); }
});
app.get('/api/health', (req, res) => res.json({ success: true, service: 'inteliflex-doctor-scheduler' }));
const publicDir = path.resolve(__dirname, '../public');
app.use(express.static(publicDir, { index: 'index.html', maxAge: isProduction ? '1h' : 0, dotfiles: 'deny' }));

// Authentication
const loginFailures = new Map();
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const LOGIN_FAILURE_LIMIT = 10;

app.post('/api/auth/login', async (req, res) => {
  try {
    const address = req.ip || req.socket.remoteAddress || 'unknown';
    const now = Date.now();
    let bucket = loginFailures.get(address);
    if (bucket && bucket.windowEndsAt <= now) {
      loginFailures.delete(address);
      bucket = null;
    }
    if (bucket?.blockedUntil > now) {
      res.setHeader('Retry-After',String(Math.ceil((bucket.blockedUntil - now) / 1000)));
      return sendError(res,429,'Too many failed sign-in attempts. Try again later.');
    }
    const username = String(req.body?.username || '').trim();
    const password = String(req.body?.password || '');
    const result = await authenticatePassword(username,password);
    if (!result.ok) {
      bucket ||= { failures: 0, windowEndsAt: now + LOGIN_WINDOW_MS, blockedUntil: 0 };
      bucket.failures++;
      if (bucket.failures >= LOGIN_FAILURE_LIMIT) bucket.blockedUntil = now + LOGIN_WINDOW_MS;
      loginFailures.set(address,bucket);
      if (loginFailures.size > 5000) {
        for (const [key,value] of loginFailures) {
          if (value.windowEndsAt <= now) loginFailures.delete(key);
          if (loginFailures.size <= 5000) break;
        }
      }
      return sendError(res,result.status || 401,result.error);
    }
    loginFailures.delete(address);
    makeSessionCookie(res,result.token);
    return res.json({ success: true, ...(isProduction ? {} : { token: result.token }), user: result.user, mustChangePassword: Boolean(result.user.must_change_password) });
  } catch (error) {
    console.error('Login failed:', error.message);
    return sendError(res,500,'Sign-in could not be completed.');
  }
});

app.get('/api/auth/me', authenticate(), async (req,res) => {
  try {
    const fresh = await getQuery('SELECT * FROM users WHERE id=?',[req.user.id]);
    if (!fresh) return sendError(res,401,'Session is invalid.');
    return res.json({ success: true, user: userPayload(fresh,await profileForUser(fresh)), mustChangePassword: Boolean(fresh.must_change_password) });
  } catch { return sendError(res,500,'Could not load the signed-in user.'); }
});

app.post('/api/auth/logout', authenticate(), async (req,res) => {
  try {
    const token = requestToken(req);
    await runQuery('DELETE FROM auth_sessions WHERE token=?',[tokenDigest(token)]);
    clearSessionCookie(res);
    return res.json({ success: true });
  } catch (error) { return sendError(res,500,'Could not sign out.'); }
});

app.post('/api/auth/change-password', authenticate(), async (req,res) => {
  const newPassword = String(req.body?.newPassword || '');
  const confirmPassword = String(req.body?.confirmPassword || '');
  if (newPassword.length < 12) return sendError(res,400,'Use a password with at least 12 characters.');
  if (newPassword !== confirmPassword) return sendError(res,400,'Passwords do not match.');
  try {
    const salt = crypto.randomBytes(16).toString('hex');
    const passwordHash = hashPassword(newPassword,salt).hash;
    await runQuery('UPDATE users SET password_hash=?,salt=?,must_change_password=0 WHERE id=?',[passwordHash,salt,req.user.id]);
    await runQuery('DELETE FROM auth_sessions WHERE user_id=? AND token<>?',[req.user.id,tokenDigest(requestToken(req))]);
    return res.json({ success: true, message: 'Password updated successfully.' });
  } catch (error) { return sendError(res,500,'Password could not be changed.'); }
});

app.post('/api/auth/forgot-password', async (req,res) => {
  try {
    const identifier = String(req.body?.identifier || '').trim();
    if (!identifier) return sendError(res,400,'Enter your username, email, or phone number.');
    if (isProduction) return res.json({ success: true, message: 'If the account exists, contact the clinic administrator through a verified channel to request a password reset.' });
    const normalPhone = normalizePhone(identifier).replace(/^\+/, '');
    const users = await allQuery('SELECT * FROM users ORDER BY id');
    let user = users.find((item) => item.username.toLowerCase() === identifier.toLowerCase() || item.email.toLowerCase() === identifier.toLowerCase());
    if (!user && normalPhone) {
      const doctors = await allQuery('SELECT id,personal_phone FROM doctors');
      const doctor = doctors.find((item) => normalizePhone(item.personal_phone).replace(/^\+/, '').endsWith(normalPhone.slice(-10)));
      if (doctor) user = users.find((item) => item.doctor_id === doctor.id);
    }
    // Keep the public response generic to prevent account enumeration.
    if (!user || !user.is_active) return res.json({ success: true, message: 'If the account can be verified, reset instructions will be sent to its registered contact.' });
    const tempPassword = crypto.randomBytes(18).toString('base64url');
    const salt = crypto.randomBytes(16).toString('hex');
    await runQuery('UPDATE users SET password_hash=?,salt=?,must_change_password=1 WHERE id=?',[hashPassword(tempPassword,salt).hash,salt,user.id]);
    const doctor = user.doctor_id ? await getQuery('SELECT personal_phone FROM doctors WHERE id=?',[user.doctor_id]) : null;
    const dispatchedTo = { email: user.email || null, whatsapp: doctor?.personal_phone || null };
    if (!isProduction) return res.json({ success: true, message: 'Temporary password generated for local testing.', tempPassword, dispatchedTo });
    if (doctor?.personal_phone) await sendWhatsAppMessage(doctor.personal_phone,'A password reset was requested for your clinic account. Contact the clinic administrator to complete the reset.');
    return res.json({ success: true, message: 'If the account can be verified, reset instructions will be sent to its registered contact.' });
  } catch (error) {
    console.error('Forgot-password request failed:',error.message);
    return sendError(res,500,'Password reset could not be started.');
  }
});

app.get('/api/auth/permissions-list', requireAdmin, (req,res) => res.json({ success: true, permissions: PERMISSIONS }));

// Doctor management
app.get('/api/doctors', async (req,res) => {
  try {
    const user = await lookupUser(req);
    const doctors = await getDoctorsForApi(user);
    return res.json({ success: true, doctors });
  } catch (error) { return sendError(res,500,'Could not load doctors.'); }
});

app.post('/api/doctors', adminOrDev, async (req,res) => {
  try {
    const result = await createDoctor(req.body || {});
    return res.status(201).json({ success: true, doctorId: result.doctorId, doctor: result.doctor, ...(result.initialPassword ? { initialPassword: result.initialPassword } : {}) });
  } catch (error) { return sendError(res,error.status || 500,error.status ? error.message : 'Could not create doctor.'); }
});

app.get('/api/doctors/:id', async (req,res) => {
  try {
    const user = await lookupUser(req);
    if (isProduction && !user) return sendError(res,401,'Authentication required.');
    if (user?.role === 'doctor' && Number(user.doctor_id) !== Number(req.params.id)) return sendError(res,403,'You can only view your own doctor profile.');
    const doctor = await getQuery('SELECT * FROM doctors WHERE id=?',[req.params.id]);
    if (!doctor) return sendError(res,404,'Doctor not found.');
    return res.json({ success: true, doctor });
  } catch (error) { return sendError(res,500,'Could not load doctor.'); }
});

app.put('/api/doctors/:id/toggle-status', adminOrDev, async (req,res) => {
  try {
    const result = await toggleDoctor(Number(req.params.id),Boolean(req.body?.cancelAppointments));
    return res.json(result);
  } catch (error) { return sendError(res,error.status || 500,error.status ? error.message : 'Could not change doctor status.'); }
});

app.put('/api/doctors/:id', adminOrDev, async (req,res) => {
  try {
    const doctor = await updateDoctor(Number(req.params.id),req.body || {});
    return res.json({ success: true, doctor });
  } catch (error) { return sendError(res,error.status || 500,error.status ? error.message : 'Could not update doctor.'); }
});

app.delete('/api/doctors/:id', requireAdmin, async (req,res) => {
  try {
    const result = await runQuery('DELETE FROM doctors WHERE id=?',[req.params.id]);
    if (!result.changes) return sendError(res,404,'Doctor not found.');
    return res.json({ success: true });
  } catch { return sendError(res,500,'Could not delete doctor.'); }
});

// Services and clinic settings
app.get('/api/services', async (req,res) => {
  try { return res.json({ success: true, services: await allQuery('SELECT * FROM services WHERE is_active=1 ORDER BY id') }); }
  catch { return sendError(res,500,'Could not load services.'); }
});

app.post('/api/services', adminOrDev, async (req,res) => {
  const body = req.body || {};
  const name = String(body.name || '').trim();
  const duration = Number(body.duration_minutes ?? 30);
  const price = Number(body.price ?? 0);
  const doctorId = Number(body.doctorId) || null;
  if (!name || name.length > 120) return sendError(res,400,'Service name is required and must be 120 characters or fewer.');
  if (!Number.isInteger(duration) || duration < 5 || duration > 480) return sendError(res,400,'Service duration must be between 5 and 480 minutes.');
  if (!Number.isFinite(price) || price < 0) return sendError(res,400,'Service price must be a non-negative number.');
  try {
    if (doctorId && !await getQuery('SELECT id FROM doctors WHERE id=? AND is_active=1',[doctorId])) return sendError(res,400,'Choose an active doctor.');
    const result = await runQuery('INSERT INTO services (doctor_id,name,duration_minutes,price,description) VALUES (?,?,?,?,?)',[doctorId,name,duration,price,String(body.description || '').slice(0,2000)]);
    const service = await getQuery('SELECT * FROM services WHERE id=?',[result.lastID]);
    return res.status(201).json({ success: true, service });
  } catch { return sendError(res,500,'Could not create service.'); }
});

app.get('/api/settings', requireAdmin, async (req,res) => {
  try { return res.json({ success: true, settings: cleanSettings(await getQuery('SELECT * FROM settings WHERE id=1')) }); }
  catch { return sendError(res,500,'Could not load clinic settings.'); }
});

app.put('/api/settings', requireAdmin, async (req,res) => {
  const editable = ['business_name','business_type','clinic_phone','owner_personal_phone','address','persona_name','persona_tone','custom_instructions','cancellation_policy','currency','currency_symbol','currency_position','country','country_code','timezone','timezone_label'];
  const body = req.body || {};
  const fields = editable.filter((key) => body[key] !== undefined);
  if (!fields.length) return res.json({ success: true, settings: cleanSettings(await getQuery('SELECT * FROM settings WHERE id=1')) });
  if (body.timezone !== undefined) {
    try { new Intl.DateTimeFormat('en-US',{timeZone:String(body.timezone)}).format(new Date()); }
    catch { return sendError(res,400,'Use a valid IANA time zone.'); }
  }
  try {
    const sql = `UPDATE settings SET ${fields.map((key) => `${key}=?`).join(',')} WHERE id=1`;
    await runQuery(sql,fields.map((key) => String(body[key] ?? '')));
    return res.json({ success: true, settings: cleanSettings(await getQuery('SELECT * FROM settings WHERE id=1')) });
  } catch { return sendError(res,500,'Could not save clinic settings.'); }
});

// Calendar and appointment operations
app.get('/api/calendar', authenticate(), async (req,res) => {
  try {
    const doctors = await getDoctorsForApi(req.user);
    const date = String(req.query.date || '');
    let appointments = await allQuery('SELECT * FROM appointments ORDER BY date,start_time');
    if (date) appointments = appointments.filter((item) => item.date === date);
    if (req.user.role === 'doctor') appointments = req.user.doctor_id ? appointments.filter((item) => Number(item.doctor_id) === Number(req.user.doctor_id)) : [];
    return res.json({ success: true, doctors, appointments });
  } catch { return sendError(res,500,'Could not load calendar.'); }
});

app.get('/api/appointments/export-csv', receptionistOrAbove, async (req,res) => {
  try {
    const rows = await listAppointments(req.query.search || '');
    const columns = [
      { key: 'id', label: 'Appointment ID' }, { key: 'doctor_name', label: 'Doctor Name' },
      { key: 'patient_name', label: 'Patient Name' }, { key: 'client_phone', label: 'Mobile Number' },
      { key: 'service_name', label: 'Service' }, { key: 'date', label: 'Date' },
      { key: 'start_time', label: 'Start Time' }, { key: 'end_time', label: 'End Time' },
      { key: 'fee', label: 'Fee' }, { key: 'status', label: 'Status' }, { key: 'notes', label: 'Notes' }
    ];
    const body = makeCsv(rows,columns);
    res.setHeader('Content-Type','text/csv; charset=utf-8');
    res.setHeader('Content-Disposition',`attachment; filename="appointments-${new Date().toISOString().slice(0,10)}.csv"`);
    return res.status(200).send(body);
  } catch { return sendError(res,500,'CSV export failed.'); }
});

app.get('/api/appointments/export-excel', receptionistOrAbove, async (req,res) => {
  try {
    const rows = await listAppointments(req.query.search || '');
    const worksheetRows = rows.map((row) => ({
      'Appointment ID': row.id,
      'Doctor Name': row.doctor_name,
      'Patient Full Name': row.patient_name,
      'Patient Name': row.patient_name,
      'Mobile Number': row.client_phone,
      'Service': row.service_name,
      'Date': row.date,
      'Start Time': row.start_time,
      'End Time': row.end_time,
      'Fee': row.fee,
      'Status': row.status,
      'Notes': row.notes || ''
    }));
    const columns = ['Appointment ID','Doctor Name','Patient Full Name','Patient Name','Mobile Number','Service','Date','Start Time','End Time','Fee','Status','Notes'];
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Appointments');
    worksheet.addRow(columns);
    worksheet.addRows(worksheetRows.map((row) => columns.map((column) => row[column] ?? '')));
    worksheet.views = [{ state: 'frozen', ySplit: 1 }];
    worksheet.getRow(1).font = { bold: true };
    const buffer = await workbook.xlsx.writeBuffer();
    res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition',`attachment; filename="appointments-${new Date().toISOString().slice(0,10)}.xlsx"`);
    return res.status(200).send(buffer);
  } catch { return sendError(res,500,'Excel export failed.'); }
});

app.get('/api/appointments', authenticate(), async (req,res) => {
  try {
    let appointments = await listAppointments(req.query.search || '');
    if (req.query.date) appointments = appointments.filter((item) => item.date === req.query.date);
    if (req.user.role === 'doctor') appointments = req.user.doctor_id ? appointments.filter((item) => Number(item.doctor_id) === Number(req.user.doctor_id)) : [];
    return res.json({ success: true, appointments });
  } catch { return sendError(res,500,'Could not load appointments.'); }
});

app.post('/api/appointments', staffOrDev, async (req,res) => {
  try {
    const result = await createAppointment(req.body || {});
    return res.json(result);
  } catch (error) { return sendError(res,error.status || 500,error.status ? error.message : 'Could not create appointment.'); }
});

app.put('/api/appointments/:id/status', staffOrDev, async (req,res) => {
  const allowed = ['confirmed','tentative','completed','cancelled','no_show'];
  const status = String(req.body?.status || '');
  if (!allowed.includes(status)) return sendError(res,400,'Invalid appointment status.');
  try {
    const result = await runQuery('UPDATE appointments SET status=?,cancelled_by=CASE WHEN ?=\'cancelled\' THEN \'clinic\' ELSE cancelled_by END WHERE id=?',[status,status,req.params.id]);
    if (!result.changes) return sendError(res,404,'Appointment not found.');
    const appointment = await getQuery('SELECT * FROM appointments WHERE id=?',[req.params.id]);
    if (status === 'cancelled' && req.body?.notifyClient) {
      const message = `Your appointment ${appointment.id} has been cancelled by the clinic. Please contact us to reschedule.`;
      await runQuery('INSERT INTO messages (phone,direction,sender_name,message) VALUES (?,?,?,?)',[appointment.client_phone,'outbound','Clinic',message]);
      await sendWhatsAppMessage(appointment.client_phone,message);
    }
    return res.json({ success: true, status, appointment });
  } catch { return sendError(res,500,'Could not update appointment status.'); }
});

app.delete('/api/appointments/:id', staffOrDev, async (req,res) => {
  try {
    const appointment = await getQuery('SELECT * FROM appointments WHERE id=?',[req.params.id]);
    if (!appointment) return sendError(res,404,'Appointment not found.');
    if (req.query.hard === 'true') await runQuery('DELETE FROM appointments WHERE id=?',[req.params.id]);
    else await runQuery("UPDATE appointments SET status='cancelled',cancelled_by='clinic' WHERE id=?",[req.params.id]);
    return res.json({ success: true });
  } catch { return sendError(res,500,'Could not delete appointment.'); }
});

app.post('/api/reminders/run', requireAdmin, async (req,res) => {
  try {
    const result = await runConfirmationCheck(req.body?.date || null,Boolean(req.body?.forceMarkUnconfirmed));
    return res.json({ success: true, ...result });
  } catch { return sendError(res,500,'Reminder scan failed.'); }
});

// Client and patient directory
app.get('/api/clients', receptionistOrAbove, async (req,res) => {
  try { return res.json({ success: true, clients: await listClients() }); }
  catch { return sendError(res,500,'Could not load clients.'); }
});

app.delete('/api/clients/:phone', staffOrDev, async (req,res) => {
  try {
    const phone = decodeURIComponent(req.params.phone);
    const result = await runQuery('DELETE FROM clients WHERE phone=?',[phone]);
    if (!result.changes) return sendError(res,404,'Client not found.');
    return res.json({ success: true });
  } catch { return sendError(res,500,'Could not delete client.'); }
});

app.get('/api/clients/sample-template', receptionistOrAbove, async (req,res) => {
  const rows = samplePatientRows();
  const format = String(req.query.format || 'csv').toLowerCase();
  const stem = `patient-import-template.${format === 'xlsx' ? 'xlsx' : 'csv'}`;
  if (format === 'xlsx') {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Patients');
    worksheet.addRows(rows);
    worksheet.views = [{ state: 'frozen', ySplit: 1 }];
    worksheet.getRow(1).font = { bold: true };
    const buffer = await workbook.xlsx.writeBuffer();
    res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition',`attachment; filename="${stem}"`);
    return res.send(buffer);
  }
  res.setHeader('Content-Type','text/csv; charset=utf-8');
  res.setHeader('Content-Disposition',`attachment; filename="${stem}"`);
  return res.send(`\uFEFF${rows.map((row) => row.map(csvEscape).join(',')).join('\r\n')}\r\n`);
});

app.post('/api/clients/import', receptionistOrAbove, upload.single('file'), async (req,res) => {
  try {
    if (!req.file) return sendError(res,400,'Upload a CSV or XLSX file.');
    const extension = path.extname(req.file.originalname).toLowerCase();
    let matrix;
    if (extension === '.csv') matrix = parseCsv(req.file.buffer.toString('utf8'));
    else if (extension === '.xlsx') matrix = await matrixFromExcelBuffer(req.file.buffer);
    else return sendError(res,400,'Only CSV and Excel .xlsx files are supported.');
    if (matrix.length > 2001 || matrix.some((row) => row.length > 32)) return sendError(res,413,'Patient import is limited to 2,000 rows and 32 columns.');
    const rows = toObjects(matrix);
    if (!rows.length) return sendError(res,400,'No valid patient rows were found in the file.');
    const result = await importPatientRows(rows);
    return res.json({ success: true, ...result });
  } catch (error) {
    console.error('Patient import failed:',error.message);
    return sendError(res,400,'The patient file could not be imported. Check the template headers and file contents.');
  }
});

// Users and role-based administration
app.get('/api/users', requireAdmin, async (req,res) => {
  try {
    const users = await allQuery('SELECT id,username,email,full_name,role,doctor_id,is_active,must_change_password,last_login,created_at FROM users ORDER BY id');
    return res.json({ success: true, users });
  } catch { return sendError(res,500,'Could not load user accounts.'); }
});

app.post('/api/users', requireAdmin, async (req,res) => {
  const body = req.body || {};
  const username = String(body.username || '').trim();
  const email = String(body.email || '').trim();
  const fullName = String(body.fullName || '').trim();
  const role = String(body.role || '');
  const doctorId = role === 'doctor' ? Number(body.doctorId) : null;
  if (!/^[a-zA-Z0-9][a-zA-Z0-9._-]{2,63}$/.test(username)) return sendError(res,400,'Choose a username with 3–64 letters, numbers, dots, underscores, or hyphens.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return sendError(res,400,'Enter a valid email address.');
  if (!fullName || fullName.length > 120) return sendError(res,400,'Enter a name no longer than 120 characters.');
  if (!['admin','director','doctor','receptionist'].includes(role)) return sendError(res,400,'Invalid user role.');
  if (req.user.role === 'director' && role === 'admin') return sendError(res,403,'Only an administrator can create another administrator.');
  try {
    if (role === 'doctor') {
      if (!doctorId) return sendError(res,400,'Select the doctor profile linked to this account.');
      const doctor = await getQuery('SELECT id FROM doctors WHERE id=? AND is_active=1',[doctorId]);
      if (!doctor) return sendError(res,400,'Choose an active doctor profile.');
      const existing = await getQuery('SELECT id FROM users WHERE doctor_id=?',[doctorId]);
      if (existing) return sendError(res,409,'This doctor profile already has a login account.');
    }
    const temporaryPassword = crypto.randomBytes(24).toString('base64url');
    const salt = crypto.randomBytes(16).toString('hex');
    await runQuery(
      'INSERT INTO users (username,email,password_hash,salt,full_name,role,doctor_id,must_change_password,permissions) VALUES (?,?,?,?,?,?,?,?,?)',
      [username,email,hashPassword(temporaryPassword,salt).hash,salt,fullName,role,doctorId,1,JSON.stringify(role === 'doctor' ? ['calendar_view','appointments_view','appointments_manage','unavailability_view','unavailability_manage'] : [])]
    );
    const user = await getQuery('SELECT id,username,email,full_name,role,doctor_id,is_active,must_change_password FROM users WHERE username=?',[username]);
    return res.status(201).json({ success: true, user, tempPassword: temporaryPassword, requiresPasswordChange: true });
  } catch (error) {
    if (String(error.message || '').includes('UNIQUE constraint failed')) return sendError(res,409,'That username or email is already in use.');
    return sendError(res,500,'Could not create user account.');
  }
});

app.put('/api/users/:id', requireAdmin, async (req,res) => {
  const user = await getQuery('SELECT * FROM users WHERE id=?',[req.params.id]);
  if (!user) return sendError(res,404,'User not found.');
  const body = req.body || {};
  const next = {
    full_name: body.fullName ?? user.full_name,
    email: body.email ?? user.email,
    role: body.role ?? user.role,
    doctor_id: body.doctorId === undefined ? user.doctor_id : (body.doctorId || null),
    is_active: body.isActive === undefined ? user.is_active : (Number(body.isActive) ? 1 : 0)
  };
  if (!['admin','director','doctor','receptionist'].includes(next.role)) return sendError(res,400,'Invalid user role.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(next.email || ''))) return sendError(res,400,'Enter a valid email address.');
  if (req.user.role === 'director' && (user.role === 'admin' || next.role === 'admin')) return sendError(res,403,'Only an administrator can manage administrator accounts.');
  if (next.role === 'doctor') {
    if (!next.doctor_id) return sendError(res,400,'Select the doctor profile linked to this account.');
    const doctor = await getQuery('SELECT id FROM doctors WHERE id=? AND is_active=1',[next.doctor_id]);
    if (!doctor) return sendError(res,400,'Choose an active doctor profile.');
    const linkedUser = await getQuery('SELECT id FROM users WHERE doctor_id=? AND id<>?',[next.doctor_id,user.id]);
    if (linkedUser) return sendError(res,409,'This doctor profile already has a login account.');
  } else {
    next.doctor_id = null;
  }
  if (user.role === 'admin' && (next.role !== 'admin' || !next.is_active)) {
    const otherAdmins = await getQuery("SELECT COUNT(*) AS count FROM users WHERE role='admin' AND is_active=1 AND id<>?",[user.id]);
    if (!otherAdmins.count) return sendError(res,400,'Keep at least one active administrator account.');
  }
  try {
    await runQuery('UPDATE users SET full_name=?,email=?,role=?,doctor_id=?,is_active=? WHERE id=?',[next.full_name,next.email,next.role,next.doctor_id,next.is_active,user.id]);
    if (!next.is_active) await runQuery('DELETE FROM auth_sessions WHERE user_id=?',[user.id]);
    return res.json({ success: true, message: 'User account updated.' });
  } catch (error) { return sendError(res,400,'Could not update user account.'); }
});

app.post('/api/users/:id/reset-password', requireAdmin, async (req,res) => {
  const user = await getQuery('SELECT * FROM users WHERE id=?',[req.params.id]);
  if (!user) return sendError(res,404,'User not found.');
  if (req.user.role === 'director' && user.role === 'admin') return sendError(res,403,'Only an administrator can reset an administrator account.');
  const temporaryPassword = crypto.randomBytes(24).toString('base64url');
  const salt = crypto.randomBytes(16).toString('hex');
  try {
    await runQuery('UPDATE users SET password_hash=?,salt=?,must_change_password=1 WHERE id=?',[hashPassword(temporaryPassword,salt).hash,salt,user.id]);
    await runQuery('DELETE FROM auth_sessions WHERE user_id=?',[user.id]);
    return res.json({
      success: true,
      tempPassword: temporaryPassword,
      requiresPasswordChange: true,
      ...(isProduction ? {} : { dispatchedTo: { email: user.email, whatsapp: null } }),
      message: isProduction
        ? 'One-time password generated. Deliver it only through a verified out-of-band channel.'
        : 'Temporary password generated for local testing.'
    });
  } catch { return sendError(res,500,'Could not reset password.'); }
});

// Sample-data purge is a one-time development-to-production action.
app.post('/api/admin/purge-sample-data', requireAdmin, async (req,res) => {
  if (isProduction) return sendError(res,404,'Sample-data purge is disabled in production.');
  try { return res.json(await purgeDemoData()); }
  catch (error) { return sendError(res,error.status || 500,error.status ? error.message : 'Could not purge sample data.'); }
});

// Text simulator for local testing; production inbound traffic comes through the signed Meta webhook.
app.post('/api/chat/send', adminOrDev, async (req,res) => {
  try {
    const phone = normalizePhone(req.body?.phone);
    const message = String(req.body?.message || '');
    if (!phone || !message) return sendError(res,400,'Phone and message are required.');
    const reply = await processIncomingMessage(phone,message,req.body?.senderName || '');
    const session = await getQuery('SELECT state FROM chat_sessions WHERE phone=?',[phone]);
    return res.json({ success: true, reply, sessionState: session?.state || 'IDLE' });
  } catch (error) {
    console.error('Chat simulator failed:',error.message);
    return sendError(res,500,'The message could not be processed.');
  }
});

// Official Meta webhook. In production every POST must include a valid app-secret signature.
app.get('/api/whatsapp/webhook', async (req,res) => {
  try {
    const mode = String(req.query['hub.mode'] || '');
    const token = String(req.query['hub.verify_token'] || '');
    const configured = process.env.META_VERIFY_TOKEN || (await getQuery('SELECT whatsapp_verify_token FROM settings WHERE id=1'))?.whatsapp_verify_token || '';
    if (mode === 'subscribe' && configured && token === configured) return res.status(200).send(String(req.query['hub.challenge'] || ''));
    return res.sendStatus(403);
  } catch { return res.sendStatus(500); }
});

app.post('/api/whatsapp/webhook', async (req,res) => {
  try {
    const config = getWhatsAppConfig();
    const signature = req.headers['x-hub-signature-256'];
    if (isProduction && (!config.appSecret || !verifyWebhookSignature(req.rawBody,signature,config.appSecret))) return res.sendStatus(401);
    const messages = extractTextMessages(req.body);
    for (const item of messages) {
      const reply = await processIncomingMessage(item.from,item.text,item.name);
      await sendWhatsAppMessage(item.from,reply);
    }
    return res.sendStatus(200);
  } catch (error) {
    console.error('Meta webhook processing failed:',error.message);
    return res.sendStatus(200); // Avoid retry storms; the server logs only the error category/message.
  }
});

// Safe default API 404 and centralized error handler.
app.use('/api', (req,res) => sendError(res,404,'API route not found.'));
app.use((error,req,res,next) => {
  console.error('Request failed:',error.message);
  if (res.headersSent) return next(error);
  const status = error.status || (error.type === 'entity.too.large' ? 413 : 500);
  return sendError(res,status,status >= 500 && isProduction ? 'The request could not be completed.' : error.message || 'The request could not be completed.');
});

let server;
let startPromise;
function startServer() {
  if (startPromise) return startPromise;
  startPromise = initDb().then(() => new Promise((resolve,reject) => {
    const port = Number(process.env.PORT) || 3000;
    const host = process.env.HOST || '0.0.0.0';
    server = app.listen(port,host,() => {
      console.log(`INTELIFLEX single-clinic scheduler listening on ${host}:${port}`);
      resolve(server);
    });
    server.once('error',reject);
  })).catch(async (error) => {
    console.error('Application startup failed:',error.message);
    try { await closeDb(); } catch {}
    process.exitCode = 1;
    throw error;
  });
  return startPromise;
}

function stopServer() {
  return new Promise((resolve) => {
    if (!server) return resolve();
    server.close(() => { server = null; resolve(); });
  });
}

// Requiring this module starts the server for the repository's integration tests and entry point.
startServer().catch(() => {});

module.exports = { app, startServer, stopServer, parseCsv, toObjects, createAppointment, purgeDemoData };
