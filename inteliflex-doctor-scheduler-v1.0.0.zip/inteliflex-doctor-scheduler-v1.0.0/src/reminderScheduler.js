'use strict';

const { initDb, getQuery, allQuery, runQuery, getClinicNow } = require('./database');
const { formatTime12 } = require('./slotManager');
const { sendWhatsAppMessage } = require('./whatsappService');

function makeReminder(appointment, timezoneLabel) {
  return [
    '*24-Hour Confirmation Reminder*',
    `Appointment ID: ${appointment.id}`,
    `Patient: ${appointment.patient_name}`,
    `Doctor: ${appointment.doctor_name}`,
    `Date: ${appointment.date}`,
    `Time: ${formatTime12(appointment.start_time)} - ${formatTime12(appointment.end_time)} (${timezoneLabel})`,
    'Reply CONFIRM to confirm, RESCHEDULE to change, or CANCEL to cancel.'
  ].join('\n');
}

async function runConfirmationCheck(targetDate = null, forceMarkUnconfirmed = false) {
  await initDb();
  const clock = await getClinicNow();
  const date = targetDate || clock.dateStr;
  if (forceMarkUnconfirmed) {
    const result = await runQuery(
      `UPDATE appointments SET status = 'tentative'
       WHERE date = ? AND status = 'confirmed' AND confirmation_sent_at IS NOT NULL AND confirmed_at IS NULL`,
      [date]
    );
    return { processed: result.changes || 0, markedTentative: result.changes || 0 };
  }

  const pending = await allQuery(
    `SELECT * FROM appointments
     WHERE date = ? AND status = 'confirmed' AND confirmation_sent_at IS NULL
     ORDER BY start_time`,
    [date]
  );
  for (const appointment of pending) {
    const message = makeReminder(appointment, clock.timezoneLabel || clock.tzAbbr);
    await runQuery('INSERT INTO messages (phone,direction,sender_name,message) VALUES (?,?,?,?)', [appointment.client_phone, 'outbound', 'INTELIFLEX Scheduler', message]);
    await sendWhatsAppMessage(appointment.client_phone, message);
    await runQuery('UPDATE appointments SET confirmation_sent_at = CURRENT_TIMESTAMP WHERE id = ?', [appointment.id]);
  }
  return { processed: pending.length, markedTentative: 0 };
}

module.exports = { runConfirmationCheck, makeReminder };
