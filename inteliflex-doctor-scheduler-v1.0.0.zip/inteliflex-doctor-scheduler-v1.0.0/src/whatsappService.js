'use strict';

const crypto = require('node:crypto');

function getWhatsAppConfig() {
  return {
    phoneNumberId: process.env.META_PHONE_NUMBER_ID || '',
    accessToken: process.env.META_ACCESS_TOKEN || '',
    appSecret: process.env.META_APP_SECRET || '',
    graphApiVersion: process.env.META_GRAPH_API_VERSION || 'v23.0'
  };
}

function verifyWebhookSignature(rawBody, signatureHeader, appSecret = getWhatsAppConfig().appSecret) {
  if (!rawBody || !signatureHeader || !appSecret) return false;
  const expected = `sha256=${crypto.createHmac('sha256', appSecret).update(rawBody).digest('hex')}`;
  const actualBuffer = Buffer.from(String(signatureHeader));
  const expectedBuffer = Buffer.from(expected);
  return actualBuffer.length === expectedBuffer.length && crypto.timingSafeEqual(actualBuffer, expectedBuffer);
}

async function sendWhatsAppMessage(to, text, options = {}) {
  const config = getWhatsAppConfig();
  if (!config.phoneNumberId || !config.accessToken) {
    return { success: false, configured: false, reason: 'WhatsApp Cloud API credentials are not configured for this clinic instance.' };
  }
  if (typeof fetch !== 'function') {
    return { success: false, configured: true, reason: 'This Node.js runtime does not provide fetch.' };
  }

  const endpoint = `https://graph.facebook.com/${config.graphApiVersion}/${encodeURIComponent(config.phoneNumberId)}/messages`;
  const body = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: String(to).replace(/[^\d]/g, ''),
    type: options.type || 'text',
    text: { preview_url: false, body: String(text).slice(0, 4000) }
  };
  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${config.accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(10000)
    });
    const responseJson = await response.json().catch(() => ({}));
    return { success: response.ok, configured: true, status: response.status, messageId: responseJson?.messages?.[0]?.id, error: response.ok ? undefined : (responseJson?.error?.message || 'Meta message delivery failed.') };
  } catch (error) {
    return { success: false, configured: true, reason: 'WhatsApp delivery request failed.', error: process.env.NODE_ENV === 'production' ? undefined : error.message };
  }
}

function extractTextMessages(payload) {
  const messages = [];
  for (const entry of payload?.entry || []) {
    for (const change of entry?.changes || []) {
      const value = change?.value || {};
      for (const message of value.messages || []) {
        let text = message?.text?.body || '';
        if (message?.type === 'button') text = message?.button?.text || message?.button?.payload || '';
        if (message?.type === 'interactive') {
          text = message?.interactive?.button_reply?.title || message?.interactive?.button_reply?.id || message?.interactive?.list_reply?.title || message?.interactive?.list_reply?.id || '';
        }
        if (message?.from && text) {
          const contact = (value.contacts || []).find((item) => item.wa_id === message.from);
          messages.push({ from: message.from, text, name: contact?.profile?.name || '' });
        }
      }
    }
  }
  return messages;
}

module.exports = { getWhatsAppConfig, verifyWebhookSignature, sendWhatsAppMessage, extractTextMessages };
