'use strict';

const { initDb, getQuery, allQuery, runQuery, getClinicNow, getDateOffset } = require('./database');
const { getAvailableDoctorSlots, acquireSlotHold, releaseSlotHold, checkSlotConflict, withSlotReservationLock, formatTime12 } = require('./slotManager');
const { sendWhatsAppMessage } = require('./whatsappService');

async function getSession(phone) {
  const row = await getQuery('SELECT state,context_data FROM chat_sessions WHERE phone = ?', [phone]);
  if (!row) return { state: 'IDLE', context: {} };
  try { return { state: row.state || 'IDLE', context: JSON.parse(row.context_data || '{}') }; }
  catch { return { state: row.state || 'IDLE', context: {} }; }
}

async function setSession(phone, state, context = {}) {
  await runQuery(
    `INSERT INTO chat_sessions (phone,state,context_data,updated_at) VALUES (?,?,?,CURRENT_TIMESTAMP)
     ON CONFLICT(phone) DO UPDATE SET state=excluded.state,context_data=excluded.context_data,updated_at=CURRENT_TIMESTAMP`,
    [phone, state, JSON.stringify(context)]
  );
}

async function writeMessage(phone, direction, message, senderName = null) {
  await runQuery('INSERT INTO messages (phone,direction,sender_name,message) VALUES (?,?,?,?)', [phone, direction, senderName, String(message)]);
}

function menuText() {
  return [
    'Welcome to the clinic appointment assistant.',
    'Reply with a number or tell me what you need:',
    '1. Book an appointment',
    '2. View or manage my bookings',
    'You can also ask about doctors, services, prices, or clinic location.'
  ].join('\n');
}

function nextWeekdayDate(targetName, timezone) {
  const names = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];
  const target = names.indexOf(targetName.toLowerCase());
  if (target < 0) return null;
  const today = getDateOffset(0, timezone);
  const currentDay = new Date(`${today}T00:00:00.000Z`).getUTCDay();
  let diff = (target - currentDay + 7) % 7;
  if (diff === 0) diff = 7;
  return getDateOffset(diff, timezone);
}

function parseRequestedDate(text, timezone) {
  const value = String(text || '').trim().toLowerCase();
  const explicit = value.match(/\b(20\d{2}-\d{2}-\d{2})\b/);
  if (explicit) return explicit[1];
  if (value.includes('today')) return getDateOffset(0, timezone);
  if (value.includes('tomorrow')) return getDateOffset(1, timezone);
  const weekdays = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];
  const named = weekdays.find((day) => new RegExp(`\\b${day}\\b`, 'i').test(value));
  return named ? nextWeekdayDate(named, timezone) : null;
}

async function getClinicProfile() {
  return getQuery('SELECT business_name,address,clinic_phone,timezone,timezone_label FROM settings WHERE id=1');
}

async function getDoctorOptions() {
  return allQuery('SELECT id,name,specialty FROM doctors WHERE is_active=1 ORDER BY id');
}

async function getServiceOptions(doctorId = null) {
  if (doctorId) {
    return allQuery('SELECT id,name,duration_minutes,price,description FROM services WHERE is_active=1 AND (doctor_id IS NULL OR doctor_id=?) ORDER BY id', [doctorId]);
  }
  return allQuery('SELECT id,name,duration_minutes,price,description FROM services WHERE is_active=1 ORDER BY id');
}

function numbered(items, render) {
  return items.map((item, index) => `${index + 1}. ${render(item)}`).join('\n');
}

async function registerClientAndPatient(phone, name) {
  const cleanName = String(name).trim().slice(0, 120);
  await runQuery('INSERT INTO clients (phone,registered_name) VALUES (?,?) ON CONFLICT(phone) DO UPDATE SET registered_name=excluded.registered_name', [phone, cleanName]);
  await runQuery('INSERT OR IGNORE INTO patients (client_phone,full_name,relationship) VALUES (?,?,?)', [phone, cleanName, 'Self']);
  return getQuery('SELECT * FROM patients WHERE client_phone=? AND full_name=?', [phone, cleanName]);
}

async function createAppointment(phone, context) {
  return withSlotReservationLock(async () => {
  await initDb();
  const activeHold = await getQuery("SELECT id FROM slot_holds WHERE id=? AND held_by_phone=? AND expires_at > datetime('now')", [context.holdId,phone]);
  if (!activeHold) throw new Error('Your temporary time hold has expired. Please start again to see current availability.');
  const conflict = await checkSlotConflict(context.doctorId,context.date,context.slot.startTime,context.slot.endTime,phone);
  if (conflict.conflict) throw new Error('That time is no longer available. Please start again to choose another slot.');
  await releaseSlotHold(context.holdId,phone);
  const currentSlots = await getAvailableDoctorSlots(context.doctorId,context.date);
  const currentSlot = currentSlots.slots.find((slot) => slot.startTime === context.slot.startTime && slot.endTime === context.slot.endTime);
  if (!currentSlot) throw new Error('That time is no longer available. Please start again to choose another slot.');
  const doctor = await getQuery('SELECT * FROM doctors WHERE id=? AND is_active=1', [context.doctorId]);
  const service = await getQuery('SELECT * FROM services WHERE id=? AND is_active=1', [context.serviceId]);
  if (!doctor || !service || !context.slot || !context.date) throw new Error('Booking details are incomplete. Please start again.');
  if (service.doctor_id && Number(service.doctor_id) !== Number(doctor.id)) throw new Error('That service is not available with the selected doctor. Please start again.');
  const patient = await getQuery('SELECT * FROM patients WHERE client_phone=? AND full_name=?', [phone, context.patientName]);
  const appointmentId = `APT-${Date.now()}${Math.floor(Math.random() * 900 + 100)}`;
  const clock = await getClinicNow();
  const startLabel = formatTime12(context.slot.startTime);
  const endLabel = formatTime12(context.slot.endTime);
  const timezoneLabel = clock.timezoneLabel || clock.tzAbbr;
  const result = await runQuery(
    `INSERT INTO appointments (
       id,doctor_id,doctor_name,doctor_phone,client_phone,patient_id,patient_name,
       service_id,service_name,date,start_time,end_time,fee,status,confirmed_at
     ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'confirmed',CURRENT_TIMESTAMP)`,
    [appointmentId, doctor.id, doctor.name, doctor.personal_phone || '', phone, patient?.id || null,
      context.patientName, service.id, service.name, context.date, context.slot.startTime,
      context.slot.endTime, Number(service.price) || 0]
  );
  if (!result.changes) throw new Error('Could not save this appointment. Please try again.');

  const confirmation = [
    `Your appointment was successfully booked.`,
    `Appointment ID: ${appointmentId}`,
    `Patient: ${context.patientName}`,
    `Doctor: ${doctor.name}`,
    `Service: ${service.name}`,
    `Date: ${context.date}`,
    `Time: ${startLabel} - ${endLabel} (${timezoneLabel})`
  ].join('\n');
  await writeMessage(phone, 'outbound', confirmation, 'INTELIFLEX Scheduler');
  const doctorAlert = [
    `New appointment booking: ${context.patientName}`,
    `Doctor: ${doctor.name}`,
    `Service: ${service.name}`,
    `Date: ${context.date}`,
    `Time: ${startLabel} - ${endLabel} (${timezoneLabel})`
  ].join('\n');
  await runQuery(
    'INSERT INTO owner_notifications (doctor_id,type,appointment_id,phone,message) VALUES (?,?,?,?,?)',
    [doctor.id, 'new_appointment', appointmentId, phone, doctorAlert]
  );
  if (doctor.personal_phone) await sendWhatsAppMessage(doctor.personal_phone, doctorAlert);
  await releaseSlotHold(context.holdId, phone);
  return { appointmentId, confirmation };
  });
}

async function processIncomingMessage(phone, message, senderName = '') {
  await initDb();
  const normalizedPhone = String(phone || '').trim();
  const text = String(message || '').trim();
  if (!normalizedPhone || !text) return 'Please send a message so I can help.';
  await writeMessage(normalizedPhone, 'inbound', text, senderName || null);

  let session = await getSession(normalizedPhone);
  let state = session.state;
  let context = session.context || {};
  const lower = text.toLowerCase();

  if (lower === 'menu' || lower === 'start over' || lower === 'restart') {
    if (context.holdId) await releaseSlotHold(context.holdId, normalizedPhone);
    await setSession(normalizedPhone, 'MENU', {});
    return menuText();
  }

  if (state === 'IDLE' || state === 'MENU') {
    if (/\b(book|schedule|appointment|reserve)\b/i.test(text) || text === '1') {
      await setSession(normalizedPhone, 'REGISTER_NAME', {});
      return 'I can help schedule that. What is the patient’s full name?';
    }
    if (/\b(my bookings|my appointments|upcoming bookings)\b/i.test(text)) {
      const bookings = await allQuery("SELECT id,doctor_name,service_name,date,start_time,status FROM appointments WHERE client_phone=? AND status IN ('confirmed','tentative') ORDER BY date,start_time", [normalizedPhone]);
      return bookings.length ? `Your upcoming appointments:\n${numbered(bookings, (item) => `${item.date} ${formatTime12(item.start_time)} — ${item.doctor_name} (${item.status})`)}` : 'I could not find any upcoming appointments for this number.';
    }
    if (/\b(price|prices|fee|fees|cost|service)\b/i.test(text)) {
      const services = await getServiceOptions();
      return services.length ? `Our services and fees:\n${numbered(services, (item) => `${item.name} — ${item.price}`)}` : 'Please contact the clinic for its current services and fees.';
    }
    if (/\b(doctor|doctors|specialist|specialists)\b/i.test(text)) {
      const doctors = await getDoctorOptions();
      return doctors.length ? `Our doctors:\n${numbered(doctors, (item) => `${item.name} — ${item.specialty}`)}` : 'The clinic has not added its doctor schedule yet.';
    }
    if (/\b(location|address|where|directions)\b/i.test(text)) {
      const profile = await getClinicProfile();
      return profile?.address ? `${profile.business_name}: ${profile.address}` : 'Please contact the clinic for its address.';
    }
    if (/\b(hi|hello|hey|good morning|good afternoon)\b/i.test(text)) return menuText();
    return `I can help with appointment scheduling, doctors, services, prices, or clinic location.\n\n${menuText()}`;
  }

  if (state === 'REGISTER_NAME') {
    if (text.length < 2 || /^\d+$/.test(text)) return 'Please enter the patient’s full name.';
    const patient = await registerClientAndPatient(normalizedPhone, text);
    context = { patientName: patient.full_name };
    const doctors = await getDoctorOptions();
    if (!doctors.length) {
      await setSession(normalizedPhone, 'IDLE', {});
      return 'The clinic has not added its doctors yet. Please contact the front desk.';
    }
    context.doctors = doctors;
    await setSession(normalizedPhone, 'SELECT_DOCTOR', context);
    return `Thank you, ${patient.full_name}. Choose a doctor:\n${numbered(doctors, (item) => `${item.name} — ${item.specialty}`)}`;
  }

  if (state === 'SELECT_DOCTOR') {
    const doctors = context.doctors || await getDoctorOptions();
    const selected = doctors[Number.parseInt(text, 10) - 1];
    if (!selected) return `Reply with a number to select a doctor:\n${numbered(doctors, (item) => item.name)}`;
    context.doctorId = selected.id;
    context.doctorName = selected.name;
    const services = await getServiceOptions(selected.id);
    context.services = services;
    await setSession(normalizedPhone, 'SELECT_SERVICE', context);
    return services.length ? `Choose a service:\n${numbered(services, (item) => `${item.name} — ${item.duration_minutes} minutes`)}` : 'The clinic has not configured appointment services yet.';
  }

  if (state === 'SELECT_SERVICE') {
    const services = context.services || await getServiceOptions(context.doctorId);
    const selected = services[Number.parseInt(text, 10) - 1];
    if (!selected) return `Reply with a number to select a service:\n${numbered(services, (item) => item.name)}`;
    context.serviceId = selected.id;
    context.serviceName = selected.name;
    await setSession(normalizedPhone, 'SELECT_DATE', context);
    return `What date would you prefer? You can reply with a weekday (for example, Monday), Tomorrow, or YYYY-MM-DD.`;
  }

  if (state === 'SELECT_DATE') {
    const settings = await getClinicProfile();
    const date = parseRequestedDate(text, settings?.timezone || 'Asia/Karachi');
    if (!date) return 'Please choose a date such as Tomorrow, Monday, or YYYY-MM-DD.';
    const availability = await getAvailableDoctorSlots(context.doctorId, date);
    if (!availability.slots.length) return `${availability.reason || 'No slots are available.'} Please try another date.`;
    context.date = date;
    context.slots = availability.slots;
    const clock = await getClinicNow();
    const timezoneLabel = clock.timezoneLabel || clock.tzAbbr;
    await setSession(normalizedPhone, 'SELECT_SLOT', context);
    return `Available slots on ${date} (${timezoneLabel}):\n${numbered(availability.slots, (slot) => `${formatTime12(slot.startTime)} - ${formatTime12(slot.endTime)}`)}\nReply with the slot number you want.`;
  }

  if (state === 'SELECT_SLOT') {
    const slots = context.slots || [];
    const slot = slots[Number.parseInt(text, 10) - 1];
    if (!slot) return `Reply with a listed slot number:\n${numbered(slots, (item) => `${formatTime12(item.startTime)} - ${formatTime12(item.endTime)}`)}`;
    const hold = await acquireSlotHold(context.doctorId, context.date, slot.startTime, slot.endTime, normalizedPhone);
    if (!hold.success) {
      const availability = await getAvailableDoctorSlots(context.doctorId, context.date);
      context.slots = availability.slots;
      await setSession(normalizedPhone, 'SELECT_SLOT', context);
      return 'That time was just taken. Please choose another available slot.';
    }
    context.slot = slot;
    context.holdId = hold.holdId;
    const service = await getQuery('SELECT name FROM services WHERE id=?', [context.serviceId]);
    const clock = await getClinicNow();
    await setSession(normalizedPhone, 'CONFIRM_BOOKING', context);
    return [
      '✅ *Hold Active* — this time is reserved for 10 minutes.',
      `⏰ Time: *${formatTime12(slot.startTime)} - ${formatTime12(slot.endTime)}*`,
      `Doctor: ${context.doctorName}`,
      `Service: ${service?.name || context.serviceName}`,
      `Date: ${context.date} (${clock.timezoneLabel || clock.tzAbbr})`,
      'Reply CONFIRM to book, or CANCEL to release the time.'
    ].join('\n');
  }

  if (state === 'CONFIRM_BOOKING') {
    if (/^cancel$/i.test(text)) {
      await releaseSlotHold(context.holdId, normalizedPhone);
      await setSession(normalizedPhone, 'IDLE', {});
      return 'Your temporary time hold has been released. You can message us again to book another time.';
    }
    if (/^confirm$/i.test(text)) {
      try {
        const result = await createAppointment(normalizedPhone, context);
        await setSession(normalizedPhone, 'IDLE', {});
        return result.confirmation;
      } catch (error) {
        await releaseSlotHold(context.holdId, normalizedPhone);
        await setSession(normalizedPhone, 'IDLE', {});
        return `I could not complete that booking: ${error.message} Please start again or contact the clinic.`;
      }
    }
    return 'Reply CONFIRM to book this held time, or CANCEL to release it.';
  }

  await setSession(normalizedPhone, 'IDLE', {});
  return menuText();
}

module.exports = { processIncomingMessage, parseRequestedDate, getSession, setSession };
