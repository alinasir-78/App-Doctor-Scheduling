'use strict';

const { initDb, getQuery, allQuery, runQuery, getClinicDateTime, getClinicNow } = require('./database');

function toMinutes(value) {
  if (!value || !/^\d{2}:\d{2}$/.test(String(value))) return NaN;
  const [hours, minutes] = String(value).split(':').map(Number);
  return hours * 60 + minutes;
}

function fromMinutes(value) {
  return `${String(Math.floor(value / 60)).padStart(2, '0')}:${String(value % 60).padStart(2, '0')}`;
}

function formatTime12(value) {
  const minutes = toMinutes(value);
  if (!Number.isFinite(minutes)) return String(value || '');
  const hour24 = Math.floor(minutes / 60);
  const minute = minutes % 60;
  const period = hour24 >= 12 ? 'PM' : 'AM';
  const hour12 = hour24 % 12 || 12;
  return `${String(hour12).padStart(2, '0')}:${String(minute).padStart(2, '0')} ${period}`;
}

function overlaps(aStart, aEnd, bStart, bEnd) {
  return aStart < bEnd && bStart < aEnd;
}

async function clinicClock() {
  return getClinicNow();
}

async function pastSlotReason(date, startTime) {
  const now = await clinicClock();
  if (date < now.dateStr) return 'past_date';
  if (date === now.dateStr && startTime <= now.timeStr) return 'past_time';
  return null;
}

async function checkSlotConflict(doctorId, date, startTime, endTime, excludeHoldPhone = null) {
  await initDb();
  const pastReason = await pastSlotReason(date, startTime);
  if (pastReason) return { conflict: true, type: pastReason, reason: pastReason };

  const unavailable = await getQuery(
    `SELECT * FROM doctor_unavailability
     WHERE doctor_id = ? AND date = ?
       AND (is_full_day = 1 OR (COALESCE(start_time,'00:00') < ? AND COALESCE(end_time,'23:59') > ?))
     LIMIT 1`,
    [doctorId, date, endTime, startTime]
  );
  if (unavailable) return { conflict: true, type: 'unavailable', reason: unavailable.reason || 'doctor_unavailable' };

  const appointments = await allQuery(
    `SELECT id FROM appointments
     WHERE doctor_id = ? AND date = ? AND status IN ('confirmed','tentative')
       AND start_time < ? AND end_time > ? LIMIT 1`,
    [doctorId, date, endTime, startTime]
  );
  if (appointments.length) return { conflict: true, type: 'appointment', reason: 'appointment_conflict', appointmentId: appointments[0].id };

  await runQuery("DELETE FROM slot_holds WHERE expires_at <= datetime('now')");
  const holds = await allQuery(
    `SELECT id, held_by_phone FROM slot_holds
     WHERE doctor_id = ? AND date = ? AND expires_at > datetime('now')
       AND start_time < ? AND end_time > ?`,
    [doctorId, date, endTime, startTime]
  );
  const otherHold = holds.find((hold) => hold.held_by_phone !== excludeHoldPhone);
  if (otherHold) return { conflict: true, type: 'hold', reason: 'held_by_patient', holdId: otherHold.id };
  return { conflict: false, type: null };
}

async function getAvailableDoctorSlots(doctorId, date) {
  await initDb();
  const clock = await clinicClock();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(date))) {
    return { available: false, slots: [], reason: 'Please choose a valid calendar date.' };
  }
  const dateObj = new Date(`${date}T00:00:00.000Z`);
  if (Number.isNaN(dateObj.getTime())) return { available: false, slots: [], reason: 'Please choose a valid calendar date.' };
  if (date < clock.dateStr) {
    return { available: false, slots: [], reason: 'Past dates cannot be booked.' };
  }
  const dayOfWeek = dateObj.getUTCDay();
  const schedule = await getQuery(
    `SELECT * FROM doctor_schedules WHERE doctor_id = ? AND day_of_week = ? AND is_active = 1`,
    [doctorId, dayOfWeek]
  );
  const doctor = await getQuery('SELECT id,is_active FROM doctors WHERE id = ?', [doctorId]);
  if (!doctor || !doctor.is_active || !schedule) {
    return { available: false, slots: [], reason: 'Doctor is not available on this date.' };
  }
  const unavailable = await getQuery('SELECT * FROM doctor_unavailability WHERE doctor_id = ? AND date = ? AND is_full_day = 1', [doctorId, date]);
  if (unavailable) return { available: false, slots: [], reason: unavailable.reason || 'Doctor is unavailable on this date.' };

  const duration = Math.max(5, Number(schedule.slot_duration_minutes) || 30);
  const increment = duration + Math.max(0, Number(schedule.buffer_minutes) || 0);
  const shiftStart = toMinutes(schedule.start_time);
  const shiftEnd = toMinutes(schedule.end_time);
  const breakStart = toMinutes(schedule.break_start);
  const breakEnd = toMinutes(schedule.break_end);
  if (![shiftStart, shiftEnd].every(Number.isFinite) || shiftEnd <= shiftStart) {
    return { available: false, slots: [], reason: 'Doctor schedule is not configured correctly.' };
  }

  const appointments = await allQuery(
    `SELECT start_time,end_time FROM appointments
     WHERE doctor_id = ? AND date = ? AND status IN ('confirmed','tentative')`,
    [doctorId, date]
  );
  await runQuery("DELETE FROM slot_holds WHERE expires_at <= datetime('now')");
  const holds = await allQuery(
    `SELECT start_time,end_time FROM slot_holds
     WHERE doctor_id = ? AND date = ? AND expires_at > datetime('now')`,
    [doctorId, date]
  );
  const partialBlocks = await allQuery(
    `SELECT start_time,end_time FROM doctor_unavailability
     WHERE doctor_id = ? AND date = ? AND is_full_day = 0`,
    [doctorId, date]
  );

  const slots = [];
  for (let start = shiftStart; start + duration <= shiftEnd; start += increment) {
    const end = start + duration;
    if (Number.isFinite(breakStart) && Number.isFinite(breakEnd) && overlaps(start, end, breakStart, breakEnd)) continue;
    if (date === clock.dateStr && fromMinutes(start) <= clock.timeStr) continue;
    const appointmentConflict = appointments.some((item) => overlaps(start, end, toMinutes(item.start_time), toMinutes(item.end_time)));
    const holdConflict = holds.some((item) => overlaps(start, end, toMinutes(item.start_time), toMinutes(item.end_time)));
    const unavailabilityConflict = partialBlocks.some((item) => overlaps(start, end, toMinutes(item.start_time || '00:00'), toMinutes(item.end_time || '23:59')));
    if (appointmentConflict || holdConflict || unavailabilityConflict) continue;
    slots.push({ startTime: fromMinutes(start), endTime: fromMinutes(end), displayTime: `${formatTime12(fromMinutes(start))} - ${formatTime12(fromMinutes(end))}` });
  }
  return { available: slots.length > 0, slots, reason: slots.length ? null : 'No available slots remain for this date.' };
}

async function getAllAvailableSlots(date) {
  await initDb();
  const doctors = await allQuery('SELECT * FROM doctors WHERE is_active = 1 ORDER BY id');
  const slots = [];
  for (const doctor of doctors) {
    const result = await getAvailableDoctorSlots(doctor.id, date);
    for (const slot of result.slots) slots.push({ ...slot, doctorId: doctor.id, doctorName: doctor.name, specialty: doctor.specialty });
  }
  return { available: slots.length > 0, slots };
}

let reservationQueue = Promise.resolve();
function withSlotReservationLock(operation) {
  const result = reservationQueue.then(operation, operation);
  reservationQueue = result.then(() => undefined, () => undefined);
  return result;
}

function acquireSlotHold(doctorId, date, startTime, endTime, phone) {
  return withSlotReservationLock(async () => {
    await initDb();
    const conflict = await checkSlotConflict(doctorId, date, startTime, endTime, phone);
    if (conflict.conflict) return { success: false, reason: conflict.type, conflict };
    const idResult = await runQuery(
      `INSERT INTO slot_holds (doctor_id,date,start_time,end_time,held_by_phone,expires_at)
       VALUES (?,?,?,?,?,?)`,
      [doctorId, date, startTime, endTime, phone, new Date(Date.now() + 10 * 60 * 1000).toISOString().replace('T', ' ').slice(0, 19)]
    );
    return { success: true, holdId: idResult.lastID, expiresInMinutes: 10 };
  });
}

async function releaseSlotHold(holdId, phone = null) {
  await initDb();
  if (holdId) return runQuery('DELETE FROM slot_holds WHERE id = ?', [holdId]);
  if (phone) return runQuery('DELETE FROM slot_holds WHERE held_by_phone = ?', [phone]);
  return { changes: 0 };
}

module.exports = {
  getAvailableDoctorSlots,
  getAllAvailableSlots,
  acquireSlotHold,
  withSlotReservationLock,
  checkSlotConflict,
  releaseSlotHold,
  formatTime12,
  toMinutes,
  fromMinutes
};
