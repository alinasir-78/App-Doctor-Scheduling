'use strict';

const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const server = require('../src/server');
const { closeDb } = require('../src/database');

const baseUrl = `http://127.0.0.1:${process.env.PORT || 3000}`;
const initialPassword = process.env.BOOTSTRAP_ADMIN_PASSWORD;

async function request(path, options = {}) {
  const response = await fetch(`${baseUrl}${path}`, options);
  const contentType = response.headers.get('content-type') || '';
  const body = contentType.includes('application/json') ? await response.json() : await response.text();
  return { response, body };
}

async function main() {
  try {
    await server.startServer();
    const home = await request('/');
    assert.equal(home.response.status,200);
    assert.match(home.response.headers.get('content-security-policy') || '',/default-src 'self'/);

    const login = await request('/api/auth/login',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({username:process.env.BOOTSTRAP_ADMIN_USERNAME,password:initialPassword})
    });
    assert.equal(login.response.status,200);
    assert.equal(login.body.token,undefined,'Production must not return a bearer token to page JavaScript.');
    assert.equal(login.body.mustChangePassword,true);
    const cookieHeader = login.response.headers.get('set-cookie') || '';
    assert.match(cookieHeader,/HttpOnly/);
    assert.match(cookieHeader,/Secure/);
    assert.match(cookieHeader,/SameSite=Strict/);
    const cookie = cookieHeader.split(';')[0];
    assert.match(cookie,/^inteliflex_session=/);

    const me = await request('/api/auth/me',{headers:{Cookie:cookie}});
    assert.equal(me.response.status,200);
    assert.equal(me.body.user.must_change_password,1);
    const blocked = await request('/api/clients',{headers:{Cookie:cookie}});
    assert.equal(blocked.response.status,403,'Forced password change should gate patient data.');

    const newPassword = crypto.randomBytes(24).toString('base64url');
    const changed = await request('/api/auth/change-password',{
      method:'POST',headers:{Cookie:cookie,'Content-Type':'application/json'},
      body:JSON.stringify({newPassword,confirmPassword:newPassword})
    });
    assert.equal(changed.response.status,200);

    const clients = await request('/api/clients',{headers:{Cookie:cookie}});
    assert.equal(clients.response.status,200);
    const privateDoctor = await request('/api/doctors/1');
    assert.equal(privateDoctor.response.status,401);
    const purge = await request('/api/admin/purge-sample-data',{
      method:'POST',headers:{Cookie:cookie,'Content-Type':'application/json'},body:'{}'
    });
    assert.equal(purge.response.status,404,'Destructive sample-data purge must be disabled in production.');

    const recovery = await request('/api/auth/forgot-password',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({identifier:process.env.BOOTSTRAP_ADMIN_USERNAME})
    });
    assert.equal(recovery.response.status,200);
    assert.match(recovery.body.message,/contact the clinic administrator/i);
    const relogin = await request('/api/auth/login',{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({username:process.env.BOOTSTRAP_ADMIN_USERNAME,password:newPassword})
    });
    assert.equal(relogin.response.status,200,'Public forgot-password requests must not change credentials.');
    assert.equal(relogin.body.mustChangePassword,false);

    const health = await request('/healthz');
    assert.equal(health.response.status,200);
    console.log('PASS production HTTP cookies, forced password change, privacy gates, purge disablement, and safe recovery behavior.');
  } finally {
    await server.stopServer();
    await closeDb();
  }
}

main().catch((error) => {
  console.error('Production HTTP test failed:',error.message);
  process.exitCode = 1;
});
