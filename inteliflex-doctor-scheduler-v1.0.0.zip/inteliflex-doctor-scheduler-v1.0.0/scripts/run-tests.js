'use strict';

const { spawn } = require('node:child_process');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const productionBootstrapEnv = {
  BOOTSTRAP_ADMIN_USERNAME: 'bootstrap-test-admin',
  BOOTSTRAP_ADMIN_EMAIL: 'bootstrap-test@example.test',
  BOOTSTRAP_ADMIN_PASSWORD: crypto.randomBytes(24).toString('base64url')
};
const suites = [
  { file: 'test-inquiry-flow.js', server: 'none' },
  { file: 'test-security.js', server: 'self' },
  { file: 'test-concurrency.js', server: 'self' },
  { file: 'test-fixes.js', server: 'self' },
  { file: 'test-csv-and-purge.js', server: 'external' },
  { file: 'test-excel-and-purge.js', server: 'external' },
  { file: 'test-doctor-mgmt.js', server: 'external' },
  { file: 'test-e2e-doctor-ui.js', server: 'external' },
  { file: 'test-timezone.js', server: 'none' },
  { file: 'scripts/test-production-bootstrap.js', server: 'none', nodeEnv: 'production', env: productionBootstrapEnv },
  { file: 'scripts/test-production-http.js', server: 'self', nodeEnv: 'production', env: productionBootstrapEnv },
  {
    file: 'scripts/test-production-bootstrap.js', server: 'none', nodeEnv: 'production',
    env: { EXPECT_BOOTSTRAP_MISSING: '1' }
  }
];
const baseEnv = {
  ...process.env,
  NODE_ENV: 'development',
  HOST: '127.0.0.1',
  PORT: '3000',
  META_PHONE_NUMBER_ID: '',
  META_WABA_ID: '',
  META_ACCESS_TOKEN: '',
  META_VERIFY_TOKEN: '',
  META_APP_SECRET: '',
  BOOTSTRAP_ADMIN_USERNAME: '',
  BOOTSTRAP_ADMIN_EMAIL: '',
  BOOTSTRAP_ADMIN_PASSWORD: '',
  CORS_ORIGINS: ''
};

function runChild(command, args, env, label) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd: root, env, stdio: 'inherit' });
    const timer = setTimeout(() => {
      child.kill('SIGTERM');
      reject(new Error(`${label} timed out after 3 minutes.`));
    }, 180_000);
    child.once('error', (error) => {
      clearTimeout(timer);
      reject(error);
    });
    child.once('exit', (code, signal) => {
      clearTimeout(timer);
      if (code === 0) resolve();
      else reject(new Error(`${label} exited with ${signal ? `signal ${signal}` : `code ${code}`}.`));
    });
  });
}

function startServer(env) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, ['index.js'], { cwd: root, env, stdio: ['ignore', 'pipe', 'pipe'] });
    let ready = false;
    let output = '';
    const timer = setTimeout(() => fail(new Error('Test server did not become ready within 20 seconds.')), 20_000);

    function relay(stream, target) {
      stream.on('data', (chunk) => {
        const text = chunk.toString();
        target.write(text);
        output = (output + text).slice(-8000);
        if (!ready && /listening on 127\.0\.0\.1:3000/.test(output)) {
          ready = true;
          clearTimeout(timer);
          resolve({ child, stop: stopServer });
        }
      });
    }

    function fail(error) {
      clearTimeout(timer);
      child.kill('SIGTERM');
      reject(error);
    }

    function stopServer() {
      return new Promise((done) => {
        if (child.exitCode !== null || child.signalCode !== null) return done();
        const stopTimer = setTimeout(() => {
          child.kill('SIGKILL');
          done();
        }, 3000);
        child.once('exit', () => {
          clearTimeout(stopTimer);
          done();
        });
        child.kill('SIGTERM');
      });
    }

    relay(child.stdout, process.stdout);
    relay(child.stderr, process.stderr);
    child.once('error', fail);
    child.once('exit', (code, signal) => {
      if (!ready) fail(new Error(`Test server exited before becoming ready (${signal || code}).`));
    });
  });
}

async function main() {
  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'inteliflex-tests-'));
  let failed = 0;
  try {
    for (const [index, suite] of suites.entries()) {
      const suiteDir = path.join(tempRoot, String(index + 1));
      fs.mkdirSync(suiteDir, { recursive: true, mode: 0o700 });
      const env = {
        ...baseEnv,
        NODE_ENV: suite.nodeEnv || baseEnv.NODE_ENV,
        ...suite.env,
        DATABASE_PATH: path.join(suiteDir, 'doctor_agent.db')
      };
      console.log(`\n${'='.repeat(72)}\nRunning ${suite.file} with an isolated temporary database\n${'='.repeat(72)}`);
      let server;
      try {
        if (suite.server === 'external') server = await startServer(env);
        await runChild(process.execPath, [suite.file], env, suite.file);
        console.log(`PASS ${suite.file}`);
      } catch (error) {
        failed++;
        console.error(`FAIL ${suite.file}: ${error.message}`);
      } finally {
        if (server) await server.stop();
      }
      if (failed) break;
    }
  } finally {
    fs.rmSync(tempRoot, { recursive: true, force: true });
  }

  if (failed) process.exitCode = 1;
  else console.log(`\nAll ${suites.length} test suites passed. Each used a fresh temporary SQLite database; no Meta credentials were loaded.`);
}

main().catch((error) => {
  console.error('Test runner failed:', error);
  process.exitCode = 1;
});
