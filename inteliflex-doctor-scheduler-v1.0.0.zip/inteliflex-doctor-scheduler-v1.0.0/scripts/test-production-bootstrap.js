'use strict';

const { initDb, getQuery, allQuery, verifyPassword, closeDb } = require('../src/database');

async function main() {
  const expectsFailure = process.env.EXPECT_BOOTSTRAP_MISSING === '1';
  try {
    await initDb();
    if (expectsFailure) throw new Error('Fresh production database unexpectedly initialized without bootstrap credentials.');

    const users = await allQuery('SELECT * FROM users ORDER BY id');
    const doctors = await getQuery('SELECT COUNT(*) AS count FROM doctors');
    const services = await getQuery('SELECT COUNT(*) AS count FROM services');
    if (users.length !== 1 || users[0].username !== process.env.BOOTSTRAP_ADMIN_USERNAME || users[0].role !== 'admin') {
      throw new Error('Production bootstrap should create exactly the configured administrator.');
    }
    if (!users[0].must_change_password || !verifyPassword(process.env.BOOTSTRAP_ADMIN_PASSWORD,users[0].password_hash,users[0].salt)) {
      throw new Error('Bootstrap administrator password or forced-change flag is incorrect.');
    }
    if (doctors.count !== 0 || services.count !== 0) throw new Error('Production must not seed development doctors or services.');
    console.log('PASS production bootstrap creates one forced-change administrator and no demo clinic data.');
  } catch (error) {
    if (!expectsFailure || !/BOOTSTRAP_ADMIN_USERNAME/.test(error.message)) throw error;
    console.log('PASS fresh production startup fails closed when bootstrap credentials are missing.');
  } finally {
    await closeDb();
  }
}

main().catch((error) => {
  console.error('Production bootstrap test failed:',error.message);
  process.exitCode = 1;
});
