'use strict';

const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const required = [
  'src/server.js',
  'src/database.js',
  'src/aiAgent.js',
  'src/whatsappService.js',
  'src/slotManager.js',
  'src/reminderScheduler.js',
  'public/index.html',
  'public/app.js',
  'public/styles.css'
];
const missing = required.filter((relative) => !fs.existsSync(path.join(root, relative)));

if (missing.length) {
  console.error('Deployment preflight failed: application runtime files are missing from this checkout:');
  for (const file of missing) console.error(`  - ${file}`);
  console.error('\nRestore or implement the application source before building or starting a deployment image.');
  process.exit(1);
}

console.log('Deployment preflight passed: expected server, data, WhatsApp, AI, and dashboard files are present.');
